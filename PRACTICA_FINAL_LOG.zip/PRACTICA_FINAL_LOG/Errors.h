#ifndef ERRORS_H_INCLUDED
#define ERRORS_H_INCLUDED

typedef struct
{
    char date[11];
    char time[6];
    char name[33];
    char msg[65];
    char email[65];
}sErrors;

#endif // ERRORS_H_INCLUDED
sErrors* err_new(char* date, char* time, char* name, char* msg, char* email);
int err_delete(sErrors* this);
int err_setDate(sErrors* this,char* date);
char* err_getDate(sErrors* this);
int err_setTime(sErrors* this,char* time);
char* err_getTime(sErrors* this);
int err_setName(sErrors* this,char* name);
char* err_getName(sErrors* this);
int err_setEmail(sErrors* this,char* email);
char* err_getEmail(sErrors* this);
int err_setMsg(sErrors* this,char* msg);
char* err_getMsg(sErrors* this);
void err_printLog(void* pWarning);
