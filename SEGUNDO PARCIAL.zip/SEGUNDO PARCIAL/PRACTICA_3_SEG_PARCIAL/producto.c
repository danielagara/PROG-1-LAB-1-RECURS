#include <stdio.h>
#include <stdlib.h>
#include "producto.h"
#include "ArrayList.h"
#include "Validaciones.h"

sProducto* prod_new(int codigoProducto, char* descripcion, float importe, int cantidad, int estado)
{
    sProducto* nuevoProducto = malloc(sizeof(sProducto));
    prod_setCodigoProducto(nuevoProducto,codigoProducto);
	prod_setDescripcion(nuevoProducto,descripcion);
	prod_setImporte(nuevoProducto,importe);
	prod_setCantidad(nuevoProducto,cantidad);
    prod_setEstado(nuevoProducto,estado);

    return nuevoProducto;
}


int prod_delete(sProducto* this)
{
    free(this);
    return 0;
}


int prod_setDescripcion(sProducto* this,char* descripcion)
{
    strcpy(this->descripcion,descripcion);
    return 0;
}


char* prod_getDescripcion(sProducto* this)
{
    return this->descripcion;
}

int prod_setCodigoProducto(sProducto* this,int codigoProducto)
{

    this->codigoProducto = codigoProducto;
    return 0;
}

int prod_getCodigoProducto(sProducto* this)
{
    return this->codigoProducto;
}

int prod_setEstado(sProducto* this,int estado)
{

    this->estado = estado;
    return 0;
}

int prod_getEstado(sProducto* this)
{
    return this->estado;
}

int prod_setImporte(sProducto* this,float importe)
{

    this->importe = importe;
    return 0;
}

float prod_getImporte(sProducto* this)
{
    return this->importe;
}

int prod_setCantidad(sProducto* this,int cantidad)
{

    this->cantidad = cantidad;
    return 0;
}

int prod_getCantidad(sProducto* this)
{
    return this->cantidad;
}

sProducto* prod_findByCodigoProducto(ArrayList* pArrayProducto, int codigoProducto)
{
    int i;
    sProducto* auxProducto;
    void* retorno=NULL;

    for(i=0;i<al_len(pArrayProducto);i++)
    {
        auxProducto = al_get(pArrayProducto,i);
        if(codigoProducto == auxProducto->codigoProducto)
        {
            retorno = auxProducto;
            break;
        }
    }

    return retorno;
}
