#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Validaciones.h"
#include "ArrayList.h"
#include "Vista.h"
#include "Controlador.h"

#include "Cliente.h"
#include "Venta.h"
#include "Informes.h"

static void opcionAltaVenta();
static void opcionBajaVenta();
static void opcionListadoVenta();
static int idiomaVista;


static void opcionAltaCliente();
static void opcionBajaCliente();
static void opcionModificacionCliente();
static void opcionListadoCliente();
static void opcionImprimeVentasXProducto();

int vista_init (int idioma)
{
    idiomaVista = idioma;
    return 0;
}

int vista_mostrarMenu()
{
    char buffer[10];
    int option=0;

    while(option != 10)
    {
        val_getInt(buffer, MENU_PPAL_ES, MENU_PPAL_ERROR_ES,2,5);
        option = atoi(buffer);

        switch(option)
        {
            case 1:
                opcionAltaCliente();
                break;
            case 2:
                opcionModificacionCliente();
                break;
            case 3:
                opcionBajaCliente();
                break;
            case 4:
                opcionListadoCliente();
                break;
            case 5:
                opcionAltaVenta();
                break;
            case 6:
                opcionBajaVenta();
                break;
            case 7:
                opcionListadoVenta();
                break;
            case 8:
                opcionImprimeVentasXProducto();
                break;
        }
    }

    return 0;
}

void vista_mostrarClientes(ArrayList* nominaClientes)
{
    cont_ordenarClientes();
    printf("\nCLIENTES\n");
    al_map(nominaClientes,cliente_imprimeCliente);


}

void vista_imprimeBien()
{
    printf("SE EJECUTO CORRECTAMENTE\n");
}
void mostrarError(char * mensaje)
{

    printf("\nIMPRIMO ERROR\n");

}

static void opcionAltaCliente()
{
    char bufferNombre[50];
    char bufferApellido[50];
    char bufferDNI[50];
    if(val_getString(bufferNombre, "Nombre? ", "Error",2,50) == 0 &&
       val_getString(bufferApellido, "Apellido? ", "Error",2,50) == 0 &&
       val_getInt(bufferDNI, "DNI? ", "Error",2,50) == 0)
    {
        cont_altaClientes(bufferNombre,bufferApellido,bufferDNI);
    }


}

static void opcionBajaCliente()
{
    char auxId[10];
    int id;

    if((val_getUnsignedInt(auxId,"Id a dar de baja" , "Error",2,10)==0))
    {
        id = atoi(auxId);
        if(cont_validaIdCLienteExistente(id)==0)
        {
            cont_bajaClientes(id);
        }
    }

}

static void opcionModificacionCliente()
{
    char auxId[10];
    int id;
    char nombre[50];
    char apellido[50];
    char DNI[50];

    if((val_getUnsignedInt(auxId,"ID A MODIFICAR" , "Error",2,10)==0))
    {
        id = atoi(auxId);
        if(cont_validaIdCLienteExistente(id) ==0)
        {
            if(val_getString(nombre, "Nombre? ", "Error",2,50) == 0 &&
           val_getString(apellido, "Apellido? ", "Error",2,50) == 0 &&
           val_getInt(DNI, "DNI? ", "Error",2,50) == 0)
            {
                cont_modificarClientes(id,nombre,apellido,DNI);
            }
        }
        else
        {
            printf("EL ID NO EXISTE\n");
        }

    }


}

static void opcionListadoCliente()
{
    cont_listarClientes();
}

//VENTA:

void vista_mostrarVentas(ArrayList* nominaVentas)
{
    printf("\nVENTAS\n");
    al_map(nominaVentas,venta_imprimeVenta);


}

static void opcionAltaVenta()
{
    char auxId[10];
    int id;
    char codigoProducto[50];
    char cantidad[50];

    if((val_getUnsignedInt(auxId,"ID DEL CLIENTE?" , "Error",2,10)==0))
    {
        id = atoi(auxId);
        if(cont_validaIdCLienteExistente(id) ==0)
        {
            if(val_getInt(codigoProducto, "Codigo Producto? ", "SOLO 1000, 1001 o 1002",2,50) == 0 && (atoi(codigoProducto)== COD_IPHONE_7 || atoi(codigoProducto)== COD_PS4 || atoi(codigoProducto)== COD_TV_LG_32))
            {
                if(val_getInt(cantidad, "Cantidad? ", "Error",2,50) == 0 )
                {
                    cont_altaVenta(id, atoi(codigoProducto), atoi(cantidad));
                }
            }
        }
        else
        {
            printf("EL ID NO EXISTE\n");
        }

    }

}

static void opcionListadoVenta()
{
    cont_listarVentas();
}


static void opcionBajaVenta()
{
    char auxId[10];
    int id;

    if((val_getUnsignedInt(auxId,"Id a dar de baja" , "Error",2,10)==0))
    {
        id = atoi(auxId);
        if(cont_validaIdVentaExistente(id)==0)
        {
            cont_bajaVenta(id);
        }
    }

}

static void opcionImprimeVentasXProducto()
{
    char codigoProducto[10];
    if(val_getInt(codigoProducto,"INGRESE EL CODIGO DEL PRODUCTO 1000, 1001, 1002\n", "ERROR", 3, 10)!=-1 && (atoi(codigoProducto)== COD_IPHONE_7 || atoi(codigoProducto)== COD_PS4 || atoi(codigoProducto)== COD_TV_LG_32))
    {
        cont_imprimeVentasXProducto(atoi(codigoProducto));
    }
}
