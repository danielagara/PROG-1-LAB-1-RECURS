#include <stdio.h>
#include <stdlib.h>
#include "interfaz.h"

int main()
{
    inter_menuConsola();
    return 0;
}
