#define ARCHIVO_SOCIOS "socios.bin"
#define ARCHIVO_SERVICIOS "servicios.bin"

int dm_readAllLogs(ArrayList* nominasLogEntry);

int dm_readAllServices(ArrayList* nominasServices);
