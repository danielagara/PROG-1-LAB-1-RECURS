#ifndef DESTINATARIOS_H_INCLUDED
#define DESTINATARIOS_H_INCLUDED
typedef struct
{
    char nombre[51];
    char apellido[51];
    int id;
    int estado;
}sDestinatarios;


#endif // DESTINATARIOS_H_INCLUDED

#define DESTINATARIO_ESTADO_ACTIVO 1
#define DESTINATARIO_ESTADO_INACTIVO 0

sDestinatarios* dest_new(char* nombre, char* apellido, int id, int estado);
int dest_delete(sDestinatarios* this);
int dest_setNombre(sDestinatarios* this,char* nombre);
char* dest_getNombre(sDestinatarios* this);
int dest_setApellido(sDestinatarios* this,char* apellido);
char* dest_getApellido(sDestinatarios* this);
int dest_setId(sDestinatarios* this,int id);
int dest_getId(sDestinatarios* this);
int dest_setEstado(sDestinatarios* this,int estado);
int dest_getEstado(sDestinatarios* this);
sDestinatarios* dest_findById(ArrayList* pArrayDestinatario, int id);
void vista_mostrarDestinatarios(ArrayList* pListaDestinatarios);
void dest_imprimeDestinatario(void* pDestinatario);
