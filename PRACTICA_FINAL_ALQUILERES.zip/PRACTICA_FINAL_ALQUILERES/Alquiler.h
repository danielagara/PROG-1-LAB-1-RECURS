#ifndef ALQUILER_H_INCLUDED
#define ALQUILER_H_INCLUDED

typedef struct
{
    int id;
    int idCliente;
    int idEquipo;
    int tiempoEstimado;
    int tiempoReal;
    int estado;
}Alquiler;

Alquiler* alq_findById(ArrayList* pArrayAlquiler, int id);
int alq_getTiempoReal(Alquiler* this);
int alq_setTiempoReal(Alquiler* this,int tiempoReal);
int alq_getTiempoEstimado(Alquiler* this);
int alq_setTiempoEstimado(Alquiler* this,int tiempoEstimado);
int alq_getIdEquipo(Alquiler* this);
int alq_setIdEquipo(Alquiler* this,int idEquipo);
int alq_getIdCliente(Alquiler* this);
int alq_setIdCliente(Alquiler* this,int idCliente);
int alq_getEstado(Alquiler* this);
int alq_setEstado(Alquiler* this,int estado);
int alq_getId(Alquiler* this);
int alq_setId(Alquiler* this,int id);
int alq_delete(Alquiler* this);
Alquiler* alq_new(int id, int idCliente, int idEquipo, int tiempoEstimado, int tiempoReal, int estado);
#endif // ALQUILER_H_INCLUDED
#define ALQUILER_ESTADO_ALQUILADO 1
#define ALQUILER_ESTADO_FINALIZADO 0
