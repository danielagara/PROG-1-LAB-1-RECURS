void cont_init();
int cont_validaIdCLienteEnVentas(int id);
int cont_altaVenta(int id, int codigoProducto, int cantidad);
int cont_bajaVenta(int id);
int cont_modificarX (int id, char* a,char* b,int c);
int cont_listarVentas();


int cont_altaClientes(char* nombre,char* apellido,char* DNI);
int cont_bajaClientes(int id);
int cont_listarClientes();
int cont_modificarClientes(int id, char* nombre,char* apellido,char* DNI);
int cont_validaIdCLienteExistente(int id);
int cont_ordenarClientes();

int cont_validaIdVentaExistente(int id);
void cont_imprimeVentasXProducto(int codigoProducto);
