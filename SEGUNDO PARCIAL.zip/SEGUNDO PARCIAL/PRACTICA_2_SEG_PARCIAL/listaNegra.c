#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Validaciones.h"
#include "listaNegra.h"
#include <string.h>

sListaNegra* LN_new(char* nombre, char* apellido, int id, int estado)
{
    sListaNegra* nuevoListaNegra = malloc(sizeof(sListaNegra));
    LN_setNombre(nuevoListaNegra,nombre);
    LN_setApellido(nuevoListaNegra,apellido);
    LN_setId(nuevoListaNegra,id);
    LN_setEstado(nuevoListaNegra,estado);

    return nuevoListaNegra;
}


int LN_delete(sListaNegra* this)
{
    free(this);
    return 0;
}


int LN_setNombre(sListaNegra* this,char* nombre)
{
    strcpy(this->nombre,nombre);
    return 0;
}


char* LN_getNombre(sListaNegra* this)
{
    return this->nombre;
}


int LN_setApellido(sListaNegra* this,char* apellido)
{
    strcpy(this->apellido,apellido);
    return 0;
}


char* LN_getApellido(sListaNegra* this)
{
    return this->apellido;
}



int LN_setId(sListaNegra* this,int id)
{

    this->id = id;
    return 0;
}

int LN_getId(sListaNegra* this)
{
    return this->id;
}

int LN_setEstado(sListaNegra* this,int estado)
{

    this->estado = estado;
    return 0;
}

int LN_getEstado(sListaNegra* this)
{
    return this->estado;
}


sListaNegra* LN_findById(ArrayList* pArrayListaNegra, int id)
{
    int i;
    sListaNegra* auxListaNegra;
    void* retorno=NULL;

    for(i=0;i<al_len(pArrayListaNegra);i++)
    {
        auxListaNegra = al_get(pArrayListaNegra,i);
        if(id == auxListaNegra->id)
        {
            retorno = auxListaNegra;
            break;
        }
    }

    return retorno;
}



void vista_mostrarListaNegra(ArrayList* pListaNegra)
{
    int i;
    sListaNegra* auxListaNegra;
    for(i=0;i<al_len(pListaNegra);i++)
        {
            auxListaNegra=al_get(pListaNegra,i);
            if(auxListaNegra->estado==1)
            {
            auxListaNegra = al_get(pListaNegra,i);
            printf("NOMBRE: %s - APELLIDO: %s- ID: %d \n",LN_getNombre(auxListaNegra), LN_getApellido(auxListaNegra),LN_getId(auxListaNegra));
            }
        }

}


void LN_imprimeListaNegra(void* pDestinatario)
{
    printf("NOMBRE %s - ID %d - APELLIDO %s\n", LN_getNombre(pDestinatario), LN_getId(pDestinatario), LN_getApellido(pDestinatario));
}
