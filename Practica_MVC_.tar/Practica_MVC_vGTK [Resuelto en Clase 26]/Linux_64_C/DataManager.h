#define ARCHIVO_SOCIOS "socios.bin"
#define ARCHIVO_SERVICIOS "servicios.bin"

int dm_saveAllSocios(ArrayList* pArraySocios);
int dm_readAllSocios(ArrayList* pArraySocios);
int dm_saveAllServicios(ArrayList* pArrayServicios);
int dm_readAllServicios(ArrayList* pArrayServicios);
