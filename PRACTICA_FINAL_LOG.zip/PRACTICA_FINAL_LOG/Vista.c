#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Validaciones.h"
#include "LogEntry.h"
#include "Services.h"
#include "ArrayList.h"
#include "Vista.h"
#include "Controlador.h"

static int idiomaVista = VISTA_IDIOMA_ES;

static void opcionAltasLogEntry();
static void opcionListadosLogEntry();

static void opcionAltasServices();
static void opcionListadosServices();

int vista_init (int idioma)
{
    idiomaVista = idioma;
    return 0;
}

int vista_mostrarMenu()
{
    char buffer[10];
    int option=0;

    while(option != 4)
    {
        val_getUnsignedInt(buffer, MENU_PPAL_ES, MENU_PPAL_ERROR_ES,2,5);
        option = atoi(buffer);

        switch(option)
        {
            case 1:
                opcionAltasLogEntry();
                opcionListadosLogEntry();
                opcionAltasServices();
                opcionListadosServices();
                break;
            case 2:
                break;
        }
    }

    return 0;
}

//PARTE sLogEntry
void vista_mostrarsLogEntry(ArrayList* pListasLogEntry)
{
    al_map(pListasLogEntry,LE_printLog);
}


void mostrarErrorsLogEntry(char *);

static void opcionAltasLogEntry()
{
    if(cont_altasLogEntry() ==0) //agregar la parte despues de services, si devuelve 0 que imprima que esta todo bien
	{
		printf("LOGS PROCESADOS\n");
	}
}


static void opcionListadosLogEntry()
{
    cont_listarsLogEntry();
}

//PARTE SERVICES
void vista_mostrarsServices(ArrayList* pListasServices)
{
    al_map(pListasServices,serv_printService);
}


void mostrarErrorsServices(char *);

static void opcionAltasServices()
{
    if(cont_altasServices() ==0)
	{
		printf("SERVICES PROCESADOS\n");
	}
}


static void opcionListadosServices()
{
    cont_listarsServices();
}
