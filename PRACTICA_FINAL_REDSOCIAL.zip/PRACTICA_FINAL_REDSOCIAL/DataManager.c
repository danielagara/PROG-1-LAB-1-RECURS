#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "DataManager.h"
#include "Validaciones.h"

#include "Usuario.h"
#include "Post.h"

//USUARIOS:
int dm_saveAllX(ArrayList* pArrayX)
{
    int i;
    int retorno=-1;
  /*  FILE* pFile=fopen("out.csv","w");
    void* pEmployees=NULL;
    if(pFile!=NULL)
    {
		fprintf(pFile,"id,first_name,last_name,age,type\n");
        for(i=0;i<al_len(list);i++)
        {
            pEmployees=al_get(list,i);
            fprintf(pFile, "%d,%s,%s,%d,%d\n", employee_getId(pEmployees),employee_getName(pEmployees), employee_getLastName(pEmployees), employee_getAge(pEmployees), employee_getType(pEmployees));

            retorno=0;
        }

    }
    fclose(pFile);*/
    return retorno;

}

int dm_readAllUsuarios(ArrayList* nominaUsuarios)
{
    int retorno=-1;
    FILE *pFile;
	Usuario* auxUsuario;

    char var1[50],var2[50],var3[50];

    pFile = fopen("usuarios.csv","r");

	if(pFile!=NULL)
    {
		fscanf(pFile,"%[^,],%[^,],%[^\n]\n",var1,var2,var3);
        do{
            if(fscanf(pFile,"%[^,],%[^,],%[^\n]\n",var1,var2,var3) >0)
			{
				if(val_validarInt(var1)!=-1 && val_validarDescripcion(var2)!=-1 && val_validarInt(var3)!=-1 )
				{
					auxUsuario=usuario_new(atoi(var1), var2,atoi(var3));
					al_add(nominaUsuarios, auxUsuario);
					retorno=0;
				}
			}
		}while(!feof(pFile));
        fclose(pFile);
	}
	return retorno;

}


//POST:
int dm_readAllPosts(ArrayList* nominaPosts)
{
    int retorno=-1;
    FILE *pFile;
	Post* auxPost;

    char var1[50],var2[50],var3[50], var4[120];

    pFile = fopen("mensajes.csv","r");

	if(pFile!=NULL)
    {
		fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3, var4);
        do{
            if(fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3,var4) >0)
			{
				if(val_validarInt(var1)!=-1 && val_validarInt(var2)!=-1&& val_validarInt(var3)!=-1 && val_validarDescripcion(var4)!=-1)
				{
					auxPost=post_new(atoi(var1), var4, atoi(var3), atoi(var2));
					al_add(nominaPosts, auxPost);
					retorno=0;
				}
			}
		}while(!feof(pFile));
        fclose(pFile);
	}
	return retorno;

}
