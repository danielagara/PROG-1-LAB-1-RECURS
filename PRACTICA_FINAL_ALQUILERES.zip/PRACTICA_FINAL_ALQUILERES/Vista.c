#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Validaciones.h"
#include "Cliente.h"

#include "ArrayList.h"
#include "Vista.h"
#include "Controlador.h"

static int idiomaVista = VISTA_IDIOMA_ES;

static void opcionAltaSocios();
static void opcionBajaSocios();
static void opcionModificacionSocios();
static void opcionListadoSocios();

static void opcionAltaServicios();
static void opcionBajaServicios();
static void opcionModificacionServicios();
static void opcionListadoServicios();


int vista_init (int idioma)
{
    idiomaVista = idioma;
    return 0;
}

int vista_mostrarMenu()
{
    char buffer[10];
    int option=0;

    while(option != 12)
    {
        val_getUnsignedInt(buffer, MENU_PPAL_ES, MENU_PPAL_ERROR_ES,2,5);
        option = atoi(buffer);

        switch(option)
        {
            case 1:
                opcionAltaClientes();
                break;
            case 2:
                opcionModificacionCliente();
                break;
            case 3:
                opcionBajaCliente();
                break;
            //PARTE ALQUILER
            case 4:
                opcionAltaAlquiler();
                break;
            case 5:
                opcionBajaAlquiler();
                break;
            case 6:
                opcionInformar();
                break;
        }
    }

    return 0;
}


