#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "DataManager.h"
#include "Validaciones.h"

#include "Cliente.h"
#include "Venta.h"

int dm_saveAllClientes(ArrayList* nominaClientes)
{
    int i;
    int retorno=-1;
    FILE* pFile=fopen("clientes.txt","w");
    void* pClientes=NULL;
    if(pFile!=NULL)
    {
		fprintf(pFile,"id,nombre,apellido,DNI,estado\n");
        for(i=0;i<al_len(nominaClientes);i++)
        {
            pClientes=al_get(nominaClientes,i);
            fprintf(pFile, "%d,%s,%s,%s,%d\n", cliente_getIdCliente(pClientes),cliente_getNombre(pClientes),cliente_getApellido(pClientes),cliente_getDNI(pClientes),cliente_getEstado(pClientes));

            retorno=0;
        }

    }
    fclose(pFile);
    return retorno;
}

int dm_readAllClientes(ArrayList* nominaClientes)
{
    int retorno=-1;
    FILE *pFile;
	Cliente* auxCliente;

    char var1[50],var2[50],var3[50],var4[50],var5[50];

    pFile = fopen("clientes.txt","r");

	if(pFile!=NULL)
    {
		fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3,var4,var5);
        do{
            if(fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3,var4,var5) >0)
			{
				if(val_validarInt(var1)!=-1 && val_validarDescripcion(var2)!=-1 && val_validarDescripcion(var3)!=-1 && val_validarInt(var4)!=-1 && val_validarInt(var5)!=-1)
				{
					auxCliente=cliente_new(atoi(var1),var2,var3,var4,atoi(var5));
					al_add(nominaClientes, auxCliente);
					retorno=0;
				}
			}
		}while(!feof(pFile));
        fclose(pFile);
	}
	return retorno;

}


//Venta
int dm_readAllVentas(ArrayList* nominaVentas)
{
    int retorno=-1;
    FILE *pFile;
	Venta* auxVenta;

    char var1[50],var2[50],var3[50],var4[50],var5[50],var6[50];

    pFile = fopen("ventas.txt","r");

	if(pFile!=NULL)
    {
		fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3,var4,var5,var6);
        do{
            if(fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3,var4,var5,var6) >0)
			{
				if(val_validarInt(var1)!=-1 && val_validarInt(var2)!=-1 && val_validarInt(var3)!=-1 && val_validarInt(var4)!=-1 && val_validarInt(var5)!=-1&& val_validarInt(var6)!=-1)
				{
					auxVenta=venta_new(atoi(var1),atoi(var2),atoi(var3),atoi(var4),atof(var5),atoi(var6));
					al_add(nominaVentas,auxVenta);
					retorno=0;
				}
			}
		}while(!feof(pFile));
        fclose(pFile);
	}
	return retorno;

}


int dm_saveAllVentas(ArrayList* nominaVentas)
{
    int i;
    int retorno=-1;
    FILE* pFile=fopen("ventas.txt","w");
    void* pVentas=NULL;
    if(pFile!=NULL)
    {
		fprintf(pFile,"idVenta,idCliente,codProducto,cantidad,precioUnitario\n");
        for(i=0;i<al_len(nominaVentas);i++)
        {
            pVentas=al_get(nominaVentas,i);
            fprintf(pFile, "%d,%d,%d,%d,%f,%d\n",venta_getIdVenta(pVentas),venta_getIdCliente(pVentas),venta_getCodProducto(pVentas),venta_getCantidad(pVentas),venta_getPrecioUnitario(pVentas),venta_getEstado(pVentas));
            retorno=0;
        }

    }
    fclose(pFile);
    return retorno;
}


int dm_saveAllIndormes(ArrayList* nominaClientes,ArrayList* nominaVentas )
{
    int i;
    int retorno=-1;
    FILE* pFile=fopen("informes.txt","w");
    void* pVentas=NULL;
    if(pFile!=NULL)
    {
		fprintf(pFile,"idVenta,idCliente,codProducto,cantidad,precioUnitario\n");
        for(i=0;i<al_len(nominaVentas);i++)
        {
            pVentas=al_get(nominaVentas,i);
            fprintf(pFile, "%d,%d,%d,%d,%f,%d\n",venta_getIdVenta(pVentas),venta_getIdCliente(pVentas),venta_getCodProducto(pVentas),venta_getCantidad(pVentas),venta_getPrecioUnitario(pVentas),venta_getEstado(pVentas));
            retorno=0;
        }

    }
    fclose(pFile);
    return retorno;
}
