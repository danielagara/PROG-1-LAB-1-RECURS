#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Vista.h"

#include "Cliente.h"
#include "Venta.h"

void inf_imprimeVentasXProducto(int codProducto, ArrayList* nominaVentas)
{
    Venta* auxVenta;
    int i;
    for(i=0;i<al_len(nominaVentas);i++)
    {
        auxVenta=(Venta*)al_get(nominaVentas,i);
        if(codProducto==venta_getCodProducto(auxVenta))
        {
            printf("CODIGO %d",venta_getCodProducto(auxVenta));
            venta_imprimeVenta(auxVenta);
        }
    }
}


void inf_imprimeVentas(ArrayList* nominaClientes, ArrayList* nominaVentas)
{
    int i;
    float montoFacturado;
    for(i=0;i<al_len(nominaVentas);i++)
    {
        Venta* pVenta=al_get(nominaVentas, i);
        Cliente* pCliente=cliente_findByIdCliente(nominaClientes,venta_getIdCliente(pVenta));
        if(pVenta!=NULL)
        {
            montoFacturado=(venta_getCantidad(pVenta)*venta_getPrecioUnitario(pVenta));
            printf("ID VENTA: %d\t NOMBRE CLIENTE: %s\t APELLIDO CLIENTE: %s\t DNI: %s\tCODIGO PRODUCTO: %d\t MONTO FACTURADO: %.2f\n",venta_getIdVenta(pVenta), cliente_getNombre(pCliente),cliente_getApellido(pCliente),cliente_getDNI(pCliente),venta_getCodProducto(pVenta),montoFacturado);
        }
    }

}
