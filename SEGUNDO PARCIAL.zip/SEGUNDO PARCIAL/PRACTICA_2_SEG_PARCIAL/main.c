#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Validaciones.h"
#include "destinatarios.h"
#include "listaNegra.h"
#include "dataManager.h"

int main()
{
    ArrayList* nominaDestinatarios;
    nominaDestinatarios=al_newArrayList();

    ArrayList* nominaListaNegra;
    nominaListaNegra=al_newArrayList();

    char nombreArchivo[50];

    //DESTINATARIOS COMUNES
    val_getDescripcion(nombreArchivo,"INGRESE EL NOMBRE DEL ARCHIVO DESTINATARIOS\n", "ERROR, NO SE ENCONTRO EL ARCHIVO", 1, 49);
    dm_readAllDestinatarios(nominaDestinatarios,nombreArchivo);

    //LISTA NEGRA
    val_getDescripcion(nombreArchivo, "INGRESE EL NOMBRE DEL ARCHIVO LISTA NEGRA\n", "ERROR, NO SE ENCONTRO EL ARCHIVO", 1, 49);
    dm_readAllListaNegra(nominaListaNegra, nombreArchivo);

    printf("DESTINATARIOS:\n");
    al_map(nominaDestinatarios,dest_imprimeDestinatario);
    printf("LISTA NEGRA:\n");
    al_map(nominaListaNegra, LN_imprimeListaNegra);

    depuralista(nominaDestinatarios, nominaListaNegra);
    dm_saveAllDestinatarios(nominaDestinatarios,"dataDepurada.csv");
    return 0;
}
