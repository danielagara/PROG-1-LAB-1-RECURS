#include "ArrayList.h"

#ifndef _VENTA_H
#define _VENTA_H
typedef struct
{
	int idVenta;
	int idCliente;
	int codProducto;
	int cantidad;
	float precioUnitario;
	int estado;
}Venta;
#endif// _VENTA_H

#define COD_TV_LG_32 1000
#define COD_PS4 1001
#define COD_IPHONE_7 1002

#define PRECIO_1000 8999.99
#define PRECIO_1001 12999.99
#define PRECIO_1002 19480.99

#define ESTADO_VENTA_ACTIVA 1
#define ESTADO_VENTA_INACTIVA 0

Venta* venta_new(int idVenta,int idCliente,int codProducto,int cantidad,float precioUnitario,int estado);
void venta_delete(Venta* this);
int venta_setIdVenta(Venta* this,int idVenta);
int venta_setIdCliente(Venta* this,int idCliente);
int venta_setCodProducto(Venta* this,int codProducto);
int venta_setCantidad(Venta* this,int cantidad);
int venta_setPrecioUnitario(Venta* this,float precioUnitario);
int venta_setEstado(Venta* this,int estado);
int venta_getIdVenta(Venta* this);
int venta_getIdCliente(Venta* this);
int venta_getCodProducto(Venta* this);
int venta_getCantidad(Venta* this);
float venta_getPrecioUnitario(Venta* this);
int venta_getEstado(Venta* this);
Venta* venta_findByIdVenta(ArrayList* pArray,int idVenta);
Venta* venta_findByIdCliente(ArrayList* pArray,int idCliente);
Venta* venta_findByCodProducto(ArrayList* pArray,int codProducto);
Venta* venta_findByCantidad(ArrayList* pArray,int cantidad);
Venta* venta_findByPrecioUnitario(ArrayList* pArray,float precioUnitario);
Venta* venta_findByEstado(ArrayList* pArray,int estado);
int venta_compareByIdVenta(void* pA ,void* pB);
int venta_compareByIdCliente(void* pA ,void* pB);
int venta_compareByCodProducto(void* pA ,void* pB);
int venta_compareByCantidad(void* pA ,void* pB);
int venta_compareByPrecioUnitario(void* pA ,void* pB);
int venta_compareByEstado(void* pA ,void* pB);
void venta_imprimeVenta (void* pVenta);
