#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Warnings.h"


sWarnings* war_new(char* date, char* time, char* name, char* msg, char* email)
{
    sWarnings* nuevosWarnings = malloc(sizeof(sWarnings));
    war_setDate(nuevosWarnings,date);
	war_setTime(nuevosWarnings,time);
    war_setName(nuevosWarnings,name);
	war_setMsg(nuevosWarnings,msg);
    war_setEmail(nuevosWarnings,email);
    return nuevosWarnings;
}

int war_delete(sWarnings* this)
{
    free(this);
    return 0;
}


int war_setDate(sWarnings* this,char* date)
{
    strcpy(this->date,date);
    return 0;
}


char* war_getDate(sWarnings* this)
{
    return this->date;
}


int war_setTime(sWarnings* this,char* time)
{
    strcpy(this->time,time);
    return 0;
}


char* war_getTime(sWarnings* this)
{
    return this->time;
}


int war_setName(sWarnings* this,char* name)
{
	strcpy(this->name,name);
    return 0;
}


char* war_getName(sWarnings* this)
{
    return this->name;
}


int war_setEmail(sWarnings* this,char* email)
{
	strcpy(this->email,email);
    return 0;
}


char* war_getEmail(sWarnings* this)
{
    return this->email;
}


int war_setMsg(sWarnings* this,char* msg)
{
	strcpy(this->msg,msg);
    return 0;
}

char* war_getMsg(sWarnings* this)
{
    return this->msg;
}


void war_printLog(void* pWarning)
{
    printf("DATE: %s - TIME: %s - NAME: %s - EMAIL: %s - MSG: %s\n", war_getDate(pWarning),war_getTime(pWarning),war_getName(pWarning), war_getEmail(pWarning),war_getMsg(pWarning));
}
