#include "ArrayList.h"

#ifndef _USUARIO_H
#define _USUARIO_H
typedef struct
{
	int idUsuario;
	char nick[51];
	int popularidad;
}Usuario;
#endif// _USUARIO_H

Usuario* usuario_new(int idUsuario,char* nick,int popularidad);
void usuario_delete(Usuario* this);
int usuario_setIdUsuario(Usuario* this,int idUsuario);
int usuario_setNick(Usuario* this,char* nick);
int usuario_setPopularidad(Usuario* this,int popularidad);
int usuario_getIdUsuario(Usuario* this);
char* usuario_getNick(Usuario* this);
int usuario_getPopularidad(Usuario* this);
Usuario* usuario_findByIdUsuario(ArrayList* pArray,int idUsuario);
Usuario* usuario_findByNick(ArrayList* pArray,char* nick);
Usuario* usuario_findByPopularidad(ArrayList* pArray,int popularidad);
int usuario_compareByIdUsuario(void* pA ,void* pB);
int usuario_compareByNick(void* pA ,void* pB);
int usuario_compareByPopularidad(void* pA ,void* pB);
void usuario_imprimeUsuario(void* pUsuario);
