#define ARCHIVO_SOCIOS "socios.bin"

int dm_saveAll(ArrayList* pArraySocios);
int dm_readAll(ArrayList* pArraySocios);
