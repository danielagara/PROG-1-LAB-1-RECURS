#include <stdio.h>
#include <stdlib.h>
#include "contratacion.h"
#include "validar.h"
#include <string.h>


//FUNCIONES PRIVADAS
static int buscarProximoIdContratacion(EContratacion* arrayContrataciones, int longitud);
//_________________________________________________________________

/** \brief buscarProximoIdContratacion genera un id autoincrementable, y lo devuelve como retorno
 *
 * \param arrayContrataciones el array al que se le genera el id
 * \param longitud lo que mide dicho array
 * \return -1 si falla, el numero de id si no hubo problemas
 *
 */

static int buscarProximoIdContratacion(EContratacion* arrayContrataciones, int longitud)
{
    int i;
    int idMax = -1;
    if(arrayContrataciones != NULL && longitud > 0)
    {
        for(i=0; i<longitud ; i++)
        {
            if(arrayContrataciones[i].flagDeEstado == ESTADO_CONTRATACION_OCUPADA)
            {
                if(idMax < arrayContrataciones[i].idContratacion)
                    idMax = arrayContrataciones[i].idContratacion;
            }
        }

    }
    return idMax + 1;
}

/** \brief buscarIndicePantalla buscara dentro del array el valor de id de pantalla pasado como parametro
 *
 * \param arrayContrataciones el array en el que se buscara dicho id
 * \param longitud lo que mide dicho array
 * \param cuitCliente el dato cuit del cliente al que le corresponde dicho id
 * \param idPantalla el dato (id) a buscar dentro del array
 * \return -1 en caso de no haberse encontrado, el valor del indice en caso de que si
 *
 */

int buscarIndiceContratacion(EContratacion* arrayContrataciones, int longitud, char* cuitCliente, int idContratacion)
{
    int i;
    int retorno = -1;
    if(arrayContrataciones != NULL && longitud > 0)
    {
        for(i=0; i<longitud ; i++)
        {
            if(idContratacion == arrayContrataciones[i].idContratacion && stricmp(arrayContrataciones[i].cuitCliente,cuitCliente)==0)
            {
                if(arrayContrataciones[i].flagDeEstado == ESTADO_CONTRATACION_OCUPADA)
                {
                    retorno = i;
                    break;
                }

            }
        }

    }
    return retorno;
}

/** \brief cont_nuevaContratacion genera el alta de una nueva contratacion, es decir, pide al usuario y guarda los datos dentro del array
 *
 * \param arrayContrataciones el array donde se introduciran los datos
 * \param index el indice del array donde se guardaran
 * \param len la longitud del array
 * \param idPantalla dato previo a validar antes de guardar
 * \return -1 en caso de error, 0 en caso de que se ejecute correctamente
 *
 */

int cont_nuevaContratacion(EContratacion* arrayContrataciones, int index, int len, int idPantalla)
{
    int retorno = -1;
    int idContratacion;
    char bCUITdelCliente[51];
	char bDiasQueDuraPublicacion[51];
	char bNombreArchivoDelVideo[100];


    if(arrayContrataciones != NULL && index >= 0 && index < len && idPantalla!=-1)
    {
          if(val_getCUIT(bCUITdelCliente,"\nCUIT DEL CLIENTE?\t","\nError: CUIT NO VALIDO\n",3,51)==0)
          {
			  if(val_getInt(bDiasQueDuraPublicacion,"\nDIAS QUE DURA LA PUBLICACION?\t","\nError: SOLO NUMEROS\n",3,51)==0)
			  {
				  if(val_getDescripcion(bNombreArchivoDelVideo,"\nNOMBRE DEL ARCHIVO DEL VIDEO?\t","\nError: INGRESE UN NOMBRE DE ARCHIVO VALIDO\n",3,100)==0)
				  {
					idContratacion = buscarProximoIdContratacion(arrayContrataciones,len);
					if(idContratacion != -1)
					{
						strncpy(arrayContrataciones[index].cuitCliente,bCUITdelCliente,51);
						arrayContrataciones[index].idPantalla = idPantalla;
						arrayContrataciones[index].diasQueDuraPublicacion=atoi(bDiasQueDuraPublicacion);
						strncpy(arrayContrataciones[index].nombreArchivoDelVideo,bNombreArchivoDelVideo,100);
						arrayContrataciones[index].flagDeEstado = ESTADO_CONTRATACION_OCUPADA;
						arrayContrataciones[index].idContratacion = idContratacion;
						printf("EL ID DE SU CONTRATACION ES: %d", arrayContrataciones[index].idContratacion);
						retorno = 0;
					}
				  }

			  }

           }

    }
    return retorno;
}

/** \brief cont_buscarIndiceContratacionLibre busca el indice que no tenga guardado otros datos de otra contratacion
 *
 * \param arrayContrataciones el array donde se realizara la busqueda
 * \param longitud lo que mide el array
 * \return -1 en caso de error, el numero del indice en caso de que se encuentre
 *
 */

int cont_buscarIndiceContratacionLibre(EContratacion* arrayContrataciones, int longitud)
{
    int retorno = -1;
    int i;
    if(arrayContrataciones != NULL && longitud > 0)
    {
        for(i=0; i<longitud ; i++)
        {
            if(arrayContrataciones[i].flagDeEstado ==ESTADO_CONTRATACION_LIBRE)
            {
                retorno =  i;
                break;
            }
        }

    }
    return retorno;
}

/** \brief cont_initProductos inicializa todos los indices del array como espacios disponibles a ocupar
 *
 * \param arrayContrataciones el array a inicializar
 * \param longitud lo que mide el array
 * \return -1 en caso de error, 0 en caso de ejecucion correcta
 *
 */

int cont_initProductos(EContratacion* arrayContrataciones, int longitud)
{
    int retorno = -1;
    int i;
    if(arrayContrataciones != NULL && longitud > 0)
    {
        for(i=0; i<longitud ; i++)
        {
            arrayContrataciones[i].flagDeEstado = ESTADO_CONTRATACION_LIBRE;
            retorno=0;
        }

    }
    return retorno;
}


/** \brief modificaContratacionPorIndice pedira y modificara los datos de una contratacion
 *
 * \param arrayContrataciones
 * \param index el indice donde se encuentra la contratacion a modificar
 * \return 0 si fue correctamente modificado, -1 si hubo algun error;
 *
 */

int modificaContratacionPorIndice(EContratacion* arrayContrataciones, int index)
{
    int retorno = -1;
    char bdiasQueDuraPublicacion[51];

    if(arrayContrataciones != NULL && index >= 0)
    {
        if(val_getInt(bdiasQueDuraPublicacion,"\nCUANTOS DIAS QUIERE QUE DURE AHORA LA CONTRATACION?\t","\nERROR: SOLO NUMEROS\n",3,51)==0)
        {
            arrayContrataciones[index].diasQueDuraPublicacion=atoi(bdiasQueDuraPublicacion);
            retorno = 0;
        }
    }
    return retorno;
}

/** \brief cont_cancelarContratacion da de baja una contratacion
 *
 * \param arrayContrataciones el array donde se dara de baja el item
 * \param len la longitud del array
 * \return -1 en caso de error, 0 si fue correctamente ejecutado
 *
 */

int cont_cancelarContratacion(EContratacion* arrayContrataciones,int len)
{
    int retorno=-1;
	char bIdContratacion[51];
	int i;

		if(val_getInt(bIdContratacion,"INGRESE EL ID DE LA CONTRATACION A DAR DE BAJA:  ","\nERROR: NO SE HA ENCONTRADO DICHO ID",2,32)==0)
		{
			if(atoi(bIdContratacion)!=-1)
			{
				for(i=0;i<len;i++)
				{
					if(arrayContrataciones[i].idContratacion==atoi(bIdContratacion))
					{
						arrayContrataciones[i].flagDeEstado=ESTADO_CONTRATACION_LIBRE;
						retorno=0;
					}
				}
			}

		}

    return retorno;
}


/** \brief cont_cuentaContrataciones cuenta la cantidad de contrataciones que tiene un cliente
 *
 * \param arrayContrataciones el array con la informacion sobre cada contratacion
 * \param len la longitud del array
 * \param CUITCliente el cuit de cada cliente a contar contrataciones
 * \return -1 si hubo algun error, el valor de la cantidad de contrataciones si no hubo errores
 *
 */

int cont_cuentaContrataciones(EContratacion* arrayContrataciones, int len, char* CUITCliente)
 {
     int retorno=-1;
     int i;
     int cantidadContrataciones=0;
     //char bCUITCliente[51];

     if(arrayContrataciones != NULL && len > 0 && CUITCliente != NULL)
     {
         for(i=0;i<len;i++)
        {
            if(stricmp(CUITCliente,arrayContrataciones[i].cuitCliente)==0 && arrayContrataciones[i].flagDeEstado==ESTADO_CONTRATACION_OCUPADA)
            {
                cantidadContrataciones++;
                retorno=cantidadContrataciones;
            }
        }
     }

	if(retorno!=-1)
	{
		printf("\nCANTIDAD DE CONTRATACIONES DEL CUIT %s: %d\n",CUITCliente, cantidadContrataciones);
	}

     return retorno;
 }


 /** \brief cont_buscaCuitsDiferentes compara todos los cuits que tienen una contratacion dada de alta, y guarda el indice de la primera
 vez que encontro cada cuit
  *
  * \param arrayContrataciones el array donde se buscan los cuits
  * \param lenContrataciones la longitud del array
  * \param arrayIndicesCUITS el array que contendra todos los indices
  * \return void
  *
  */

void cont_buscaCuitsDiferentes(EContratacion* arrayContrataciones, int lenContrataciones, int* arrayIndicesCUITS)
{
    int i=0;
	int j, k=0;
    int flagDuplicado=0;
    int index=0;

    if(arrayContrataciones!=NULL && lenContrataciones >0 && arrayIndicesCUITS != NULL)
    {
        for(k=0;k<lenContrataciones;k++)
        {
            arrayIndicesCUITS[k]=-1;
        }

        for(i = 0; i < lenContrataciones; i++)
        {
            for(j = 0; j < index; j++)
            {
                if(stricmp(arrayContrataciones[i].cuitCliente,arrayContrataciones[j].cuitCliente)==0)
                {
                    flagDuplicado = 1;
                    break;
                }
            }
            if(flagDuplicado!=1 && arrayContrataciones[i].flagDeEstado==ESTADO_CONTRATACION_OCUPADA && arrayContrataciones[j].flagDeEstado==ESTADO_CONTRATACION_OCUPADA)
            {
                arrayIndicesCUITS[index] = i;
                index++;
            }
            flagDuplicado = 0;
        }
    }
}
