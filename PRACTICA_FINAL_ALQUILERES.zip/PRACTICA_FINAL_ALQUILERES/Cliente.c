#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Cliente.h"


sCliente* cli_new( int id, char* DNI, char* nombre, char* apellido, int estado)
{
    sCliente* nuevosCliente = malloc(sizeof(sCliente));
    cli_setDNI(nuevosCliente,DNI);
    cli_setnombre(nuevosCliente,nombre);
    cli_setid(nuevosCliente,id);
    cli_setestado(nuevosCliente,estado);
    cli_setapellido(nuevosCliente,apellido);

    return nuevosCliente;
}

int cli_delete(sCliente* this)
{
    free(this);
    return 0;
}


int cli_setDNI(sCliente* this,char* DNI)
{
    strcpy(this->DNI,DNI);
    return 0;
}


char* cli_getDNI(sCliente* this)
{
    return this->DNI;
}


int cli_setnombre(sCliente* this,char* nombre)
{
    strcpy(this->nombre,nombre);
    return 0;
}


char* cli_getnombre(sCliente* this)
{
    return this->nombre;
}


int cli_setid(sCliente* this,char* id)
{
	this->id = id;
    return 0;
}


int cli_getid(sCliente* this)
{
    return this->id;
}


int cli_setestado(sCliente* this,int estado)
{

    this->estado = estado;
    return 0;
}

int cli_getestado(sCliente* this)
{
    return this->estado;
}

int cli_setapellido(sCliente* this,int apellido)
{
	strcpy(this->apellido,apellido);
    return 0;
}

char* cli_getapellido(sCliente* this)
{
    return this->apellido;
}


sCliente* cli_findById(ArrayList* pArraysCliente, int id)
{
    int i;
    sCliente *auxsCliente;
    void* retorno=NULL;

    for(i=0;i<al_len(pArraysCliente);i++)
    {
        auxsCliente = al_get(pArraysCliente,i);
        if(id == auxsCliente->id)
        {
            retorno = auxsCliente;
            break;
        }
    }

    return retorno;
}

void cli_printCliente(void* pCliente)
{
    printf("DNI: %s - nombre: %s - id: %d - estado: %d - apellido: %s\n", cli_getDNI(pCliente),cli_getnombre(pCliente),cli_getid(pCliente), cli_getestado(pCliente),cli_getapellido(pCliente));
}
