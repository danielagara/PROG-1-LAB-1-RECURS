#define ARCHIVO_SOCIOS "socios.bin"

int dm_saveAllX(ArrayList* pArrayX);
int dm_readAllPosts(ArrayList* nominaPosts);


int dm_readAllUsuarios(ArrayList* nominaUsuarios);
