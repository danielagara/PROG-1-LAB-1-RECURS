#define ARCHIVO_SOCIOS "socios.bin"
#define ARCHIVO_SERVICIOS "servicios.bin"
#define ARCHIVO_SOCIOS_SERVICIOS "sociosservicios.bin"

int dm_saveAllSocios(ArrayList* pArraySocios);
int dm_readAllSocios(ArrayList* pArraySocios);
int dm_saveAllServicios(ArrayList* pArrayServicios);
int dm_readAllServicios(ArrayList* pArrayServicios);
int dm_saveAllSociosServicios(ArrayList* pArraySociosServicios);
int dm_readAllSociosServicios(ArrayList* pArraySociosServicios);

