#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "LogEntry.h"
#include "Services.h"
#include "DataManager.h"

int dm_readAllLogs(ArrayList* nominasLogEntry)
{
    FILE *pFile;
	sLogEntry* auxsLogEntry;
	int retorno=-1;

    char var1[50],var2[50],var3[50],var4[50],var5[65];

    pFile = fopen("log.txt","r");

	if(pFile!=NULL)
    {
        do{
            if(fscanf(pFile,"%[^;];%[^;];%[^;];%[^;];%[^\n]\n",var1,var2,var3,var4,var5) >0)
			{
				if(val_validarDate(var1)!=-1 && val_validarTime(var2)!=-1 && val_validarInt(var3)!=-1 && val_validarInt(var4)!=-1 && val_validarDescripcion(var5)!=-1)
				{
					auxsLogEntry=LE_new(var1, var2, atoi(var3),atoi(var4),var5);
					al_add(nominasLogEntry, auxsLogEntry);
					retorno=0;
				}
			}
		}while(!feof(pFile));
        fclose(pFile);
	}
	return retorno;
}

int dm_readAllServices(ArrayList* nominasServices)
{
    FILE *pFile;
	sServices* auxsServices;
	int retorno=-1;

    char var1[50],var2[50],var3[50];

    pFile = fopen("services.txt","r");

	if(pFile!=NULL)
    {
        do{
            if(fscanf(pFile,"%[^;];%[^;];%[^\n]\n",var1,var2,var3) >0)
			{
				if(val_validarInt(var1)!=-1 && val_validarDescripcion(var2)!=-1 && val_validarMail(var3)!=-1)
				{
					auxsServices=serv_new(atoi(var1), var2, var3);
					al_add(nominasServices, auxsServices);
					retorno=0;
				}
			}
		}while(!feof(pFile));
        fclose(pFile);
	}
	return retorno;
}
