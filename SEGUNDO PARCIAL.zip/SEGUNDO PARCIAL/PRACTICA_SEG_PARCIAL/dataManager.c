#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Empleados.h"
#include "DataManager.h"
#include "Validaciones.h"

int dm_readAllEmpleados(ArrayList* nominaEmpleados)
{
	FILE *pFile;
	Empleado* auxEmpleado;
	int retorno=-1;
	int maxId=0;
	int auxId;
    char var1[50],var3[50],var2[50];
	//char buffer[50];

    pFile = fopen("data.csv","r");

	if(pFile!=NULL)
    {
		fscanf(pFile,"%[^;];%[^;];%[^\n]\n",var1,var2,var3);
        do{
            if(fscanf(pFile,"%[^;];%[^;];%[^\n]\n",var1,var2,var3) >0)
			{
				if(val_validarInt(var1)!=-1 && val_validarDescripcion(var2)!=-1 && val_validarFloat(var3)!=-1)
				{
					auxEmpleado=emp_new(var2, atof(var3), atoi(var1), EMPLEADO_ESTADO_ACTIVO);
					al_add(nominaEmpleados, auxEmpleado);
					auxId=emp_getId(auxEmpleado);
					if(auxId>maxId)
					{
						maxId=auxId;
					}
					retorno=maxId;
				}
			}
		}while(!feof(pFile));
        fclose(pFile);
	}
	return retorno;
}


int dm_saveAllEmpleados(ArrayList* nominaEmpleados)
{
    int i;
    int retorno=-1;
    FILE* pArchivoEmpleados=fopen("data.csv","w");
    void* pEmpleado=NULL;
    if(pArchivoEmpleados!=NULL)
    {
		fprintf(pArchivoEmpleados,"id;nombre;salario\n");
        for(i=0;i<al_len(nominaEmpleados);i++)
        {
            pEmpleado=al_get(nominaEmpleados,i);
            fprintf(pArchivoEmpleados, "%d;%s;%f\n", emp_getId(pEmpleado), emp_getNombre(pEmpleado), emp_getSalario(pEmpleado));

            retorno=0;
        }

    }
    fclose(pArchivoEmpleados);
    return retorno;
}
