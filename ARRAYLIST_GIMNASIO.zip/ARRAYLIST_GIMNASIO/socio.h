#ifndef SOCIO_H_INCLUDED
#define SOCIO_H_INCLUDED

#define NAME_SIZE 51
#define LAST_NAME_SIZE 51
#define DNI_SIZE 10

typedef struct
{
    int idSocio;
    int flagDeEstado;
    char nombre[NAME_SIZE];
    char apellido[LAST_NAME_SIZE];
    char DNI[DNI_SIZE];
}ESocio;

ESocio* socio_newConstructor(char *nombre,char *apellido, char* DNI,int idSocio);
int socio_setNombre(ESocio* pSocio, char *nombre);
int socio_setApellido(ESocio* pSocio, char *apellido);
int socio_setidSocio(ESocio* pSocio, int idSocio);
int socio_setDNI(ESocio* pSocio, char* DNI);
int socio_setEstadoOcupado(ESocio* pSocio);
int socio_setEstadoLibre(ESocio* pSocio);
int socio_getidSocio(ESocio* pSocio);
char* socio_getApellido(ESocio* pSocio);
char* socio_getNombre(ESocio* pSocio);
char* socio_getDNI(ESocio* pSocio);
int socio_getEstado(ESocio* pSocio);

#endif // SOCIO_H_INCLUDED

#define ESTADO_SOCIO_OCUPADO 1
#define ESTADO_SOCIO_LIBRE 0
