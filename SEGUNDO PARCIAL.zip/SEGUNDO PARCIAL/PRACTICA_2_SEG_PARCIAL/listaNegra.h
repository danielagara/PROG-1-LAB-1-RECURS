#ifndef LISTANEGRA_H_INCLUDED
#define LISTANEGRA_H_INCLUDED

typedef struct
{
    char nombre[51];
    char apellido[51];
    int id;
    int estado;
}sListaNegra;


#endif // LISTANEGRA_H_INCLUDED
#define LISTA_NEGRA_ESTADO_ACTIVO 1
#define LISTA_NEGRA_ESTADO_INACTIVO 0

sListaNegra* LN_new(char* nombre, char* apellido, int id, int estado);
int LN_delete(sListaNegra* this);
int LN_setNombre(sListaNegra* this,char* nombre);
char* LN_getNombre(sListaNegra* this);
int LN_setApellido(sListaNegra* this,char* apellido);
char* LN_getApellido(sListaNegra* this);
int LN_setId(sListaNegra* this,int id);
int LN_getId(sListaNegra* this);
int LN_setEstado(sListaNegra* this,int estado);
int LN_getEstado(sListaNegra* this);
sListaNegra* LN_findById(ArrayList* pArrayListaNegra, int id);
void vista_mostrarListaNegra(ArrayList* pListaNegra);
void LN_imprimeListaNegra(void* pDestinatario);
