#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Services.h"


sServices* serv_new(int id, char* name, char* email)
{
    sServices* nuevosServices = malloc(sizeof(sServices));
    serv_setId(nuevosServices,id);
    serv_setName(nuevosServices,name);
    serv_setEmail(nuevosServices,email);

    return nuevosServices;
}

int serv_delete(sServices* this)
{
    free(this);
    return 0;
}


int serv_setName(sServices* this,char* name)
{
    strcpy(this->name,name);
    return 0;
}


char* serv_getName(sServices* this)
{
    return this->name;
}


int serv_setEmail(sServices* this,char* email)
{
    strcpy(this->email,email);
    return 0;
}


char* serv_getEmail(sServices* this)
{
    return this->email;
}


int serv_setId(sServices* this,int id)
{
	this->id = id;
    return 0;
}


int serv_getId(sServices* this)
{
    return this->id;
}



/*sServices* serv_findById(ArrayList* pArraysServices, int id)
{
    int i;
    sServices *auxsServices;
    void* retorno=NULL;

    for(i=0;i<al_len(pArraysServices);i++)
    {
        auxsServices = al_get(pArraysServices,i);
        if(id == auxsServices->id)
        {
            retorno = auxsServices;
            break;
        }
    }

    return retorno;
}*/

void serv_printService(void* pService)
{
    printf("ID: %d - NAME: %s - EMAIL: %s\n", serv_getId(pService),serv_getName(pService),serv_getEmail(pService));
}
