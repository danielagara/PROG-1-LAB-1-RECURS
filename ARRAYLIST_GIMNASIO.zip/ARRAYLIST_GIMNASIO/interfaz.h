#ifndef INTERFAZ_H_INCLUDED
#define INTERFAZ_H_INCLUDED

void inter_menuConsola(void);

#endif // INTERFAZ_H_INCLUDED
