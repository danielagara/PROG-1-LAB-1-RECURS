#define ARCHIVO_SOCIOS "socios.bin"

int dm_saveAllVentas(ArrayList* nominaVentas);
int dm_readAllVentas(ArrayList* nominaVentas);


int dm_saveAllClientes(ArrayList* nominaClientes);
int dm_readAllClientes(ArrayList* nominaClientes);
