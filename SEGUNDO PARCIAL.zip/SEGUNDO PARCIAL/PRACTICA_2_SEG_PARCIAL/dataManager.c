#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "destinatarios.h"
#include "listaNegra.h"
#include "dataManager.h"
#include "Validaciones.h"
#include <string.h>
int dm_readAllDestinatarios(ArrayList* nominaDestinatarios, char* nombreArchivo)
{
	FILE *pFile;
	sDestinatarios* auxDestinatario;
	int retorno=-1;
	int maxId=0;
	int auxId;
    char var1[50],var2[50],var3[50];

    pFile = fopen(nombreArchivo,"r");

	if(pFile!=NULL)
    {
		//fscanf(pFile,"%[^;];%[^;];%[^\n]\n",var1,var2,var3);
        do{
            if(fscanf(pFile,"%[^;];%[^;];%[^\n]\n",var1,var2,var3) >0)
			{
				if(val_validarDescripcion(var1)!=-1 && val_validarDescripcion(var2)!=-1 && val_validarInt(var3)!=-1)
				{
					auxDestinatario=dest_new(var1, var2, atoi(var3), 1);
					al_add(nominaDestinatarios, auxDestinatario);
					auxId=dest_getId(auxDestinatario);
					if(auxId>maxId)
					{
						maxId=auxId;
					}
					retorno=maxId;
				}
			}
		}while(!feof(pFile));
        fclose(pFile);
	}
	return retorno;
}


int dm_saveAllDestinatarios(ArrayList* nominaDestinatarios, char* nombreArchivo)
{
    int i;
    int retorno=-1;
    FILE* pFile=fopen(nombreArchivo,"w");
    void* pDestinatario=NULL;
    if(pFile!=NULL)
    {
		//fprintf(pFile,"id;nombre;salario\n");
        for(i=0;i<al_len(nominaDestinatarios);i++)
        {
            pDestinatario=al_get(nominaDestinatarios,i);
            fprintf(pFile, "%s;%s;%d\n", dest_getNombre(pDestinatario), dest_getApellido(pDestinatario), dest_getId(pDestinatario));

            retorno=0;
        }

    }
    fclose(pFile);
    return retorno;
}



//LISTA NEGRA

int dm_readAllListaNegra(ArrayList* nominaListaNegra, char* nombreArchivo)
{
	FILE *pFile;
	sListaNegra* auxListaNegra;
	int retorno=-1;
	int maxId=0;
	int auxId;
    char var1[50],var2[50],var3[50];

    pFile = fopen(nombreArchivo,"r");

	if(pFile!=NULL)
    {
		//fscanf(pFile,"%[^;];%[^;];%[^\n]\n",var1,var2,var3);
        do{
            if(fscanf(pFile,"%[^;];%[^;];%[^\n]\n",var1,var2,var3) >0)
			{
				if(val_validarDescripcion(var1)!=-1 && val_validarDescripcion(var2)!=-1 && val_validarInt(var3)!=-1)
				{
					auxListaNegra=LN_new(var1, var2, atoi(var3), 1);
					al_add(nominaListaNegra, auxListaNegra);
					auxId=LN_getId(auxListaNegra);
					if(auxId>maxId)
					{
						maxId=auxId;
					}
					retorno=maxId;
				}
			}
		}while(!feof(pFile));
        fclose(pFile);
	}
	return retorno;
}


int dm_saveAllListaNegra(ArrayList* nominaListaNegra, char* nombreArchivo)
{
    int i;
    int retorno=-1;
    FILE* pFile=fopen(nombreArchivo,"w");
    void* pListaNegra=NULL;
    if(pFile!=NULL)
    {
		//fprintf(pFile,"id;nombre;salario\n");
        for(i=0;i<al_len(nominaListaNegra);i++)
        {
            pListaNegra=al_get(nominaListaNegra,i);
            fprintf(pFile, "%s;%s;%d\n", dest_getNombre(pListaNegra), dest_getApellido(pListaNegra), dest_getId(pListaNegra));

            retorno=0;
        }

    }
    fclose(pFile);
    return retorno;
}



void depuralista(ArrayList* nominaDestinatarios, ArrayList* nominaListaNegra)
{
	ArrayList* nominaTemporal;
	nominaTemporal=al_newArrayList();
	int i;

	for(i=0;i<al_len(nominaDestinatarios); i++)
    {
        if(compare(nominaListaNegra,al_get(nominaDestinatarios, i)) ==0)
        {
               al_add(nominaTemporal, al_get(nominaDestinatarios, i));
        }
        /*if((al_contains(nominaDestinatarios,(void*)al_get(nominaListaNegra, i)) )== 0)
        {
            al_add(nominaTemporal, al_get(nominaListaNegra, i));
        }*/
    }


    al_clear(nominaDestinatarios);
    al_map(nominaDestinatarios, dest_imprimeDestinatario);
    for(i=0;i<al_len(nominaTemporal);i++)
    {
        al_add(nominaDestinatarios, al_get(nominaTemporal, i));
    }

    printf("FINAL\n");
    al_deleteArrayList(nominaTemporal);
    al_map(nominaDestinatarios,dest_imprimeDestinatario);
}



int compare(ArrayList* nominaListaNegra, sDestinatarios* pDestinatario)
{
    int i;
    int retorno=-1;
    for(i=0;i<al_len(nominaListaNegra); i++)
    {
        if(stricmp(dest_getNombre(pDestinatario),LN_getNombre(al_get(nominaListaNegra, i)))==0)
        {
            retorno=1; //ES IGUAL, ASI QUE NO VA
            break;
        }
        else if (stricmp(dest_getNombre(pDestinatario),LN_getNombre(al_get(nominaListaNegra, i)))<0 || stricmp(dest_getNombre(pDestinatario),LN_getNombre(al_get(nominaListaNegra, i)))>0)
        {
            retorno=0; //ES DISTINTO ASI QUE VA
        }
    }

    return retorno;
}
