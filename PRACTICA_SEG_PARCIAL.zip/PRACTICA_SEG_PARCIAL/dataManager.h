#ifndef DATAMANAGER_H_INCLUDED
#define DATAMANAGER_H_INCLUDED



#endif // DATAMANAGER_H_INCLUDED
#define ARCHIVO_EMPLEADO "data.csv"
int dm_readAllEmpleados(ArrayList* nominaEmpleados);

int dm_saveAllEmpleados(ArrayList* nominaEmpleados);
