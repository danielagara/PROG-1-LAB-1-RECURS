#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Alquiler.h"


Alquiler* alq_new(int id, int idCliente, int idEquipo, int tiempoEstimado, int tiempoReal, int estado)
{
    Alquiler* nuevoAlquiler = malloc(sizeof(Alquiler));
    alq_setId(nuevoAlquiler,id);
	alq_setIdCliente(nuevoAlquiler,idCliente);
	alq_setIdEquipo(nuevoAlquiler,idEquipo);
	alq_setTiempoEstimado(nuevoAlquiler,tiempoEstimado);
	alq_setTiempoReal(nuevoAlquiler,tiempoReal);
    alq_setEstado(nuevoAlquiler,estado);

    return nuevoAlquiler;
}


int alq_delete(Alquiler* this)
{
    free(this);
    return 0;
}


int alq_setId(Alquiler* this,int id)
{

    this->id = id;
    return 0;
}

int alq_getId(Alquiler* this)
{
    return this->id;
}

int alq_setEstado(Alquiler* this,int estado)
{

    this->estado = estado;
    return 0;
}

int alq_getEstado(Alquiler* this)
{
    return this->estado;
}


int alq_setIdCliente(Alquiler* this,int idCliente)
{

    this->idCliente = idCliente;
    return 0;
}

int alq_getIdCliente(Alquiler* this)
{
    return this->idCliente;
}

int alq_setIdEquipo(Alquiler* this,int idEquipo)
{

    this->idEquipo = idEquipo;
    return 0;
}

int alq_getIdEquipo(Alquiler* this)
{
    return this->idEquipo;
}

int alq_setTiempoEstimado(Alquiler* this,int tiempoEstimado)
{

    this->tiempoEstimado = tiempoEstimado;
    return 0;
}

int alq_getTiempoEstimado(Alquiler* this)
{
    return this->tiempoEstimado;
}

int alq_setTiempoReal(Alquiler* this,int tiempoReal)
{

    this->tiempoReal = tiempoReal;
    return 0;
}

int alq_getTiempoReal(Alquiler* this)
{
    return this->tiempoReal;
}



Alquiler* alq_findById(ArrayList* pArrayAlquiler, int id)
{
    int i;
    Alquiler *auxAlquiler;
    void* retorno=NULL;

    for(i=0;i<al_len(pArrayAlquiler);i++)
    {
        auxAlquiler = al_get(pArrayAlquiler,i);
        if(id == auxAlquiler->id)
        {
            retorno = auxAlquiler;
            break;
        }
    }

    return retorno;
}
