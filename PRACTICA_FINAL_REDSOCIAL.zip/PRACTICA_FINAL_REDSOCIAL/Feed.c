#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Feed.h"

Feed* feed_new(int idMensaje,char* nick,int popularidadMensaje,int idUsuario,char* mensaje,int popularidadUsuario)
{
	Feed* this = malloc(sizeof(Feed));
	if(this != NULL)
	{

		feed_setIdMensaje(this,idMensaje);
		feed_setMensaje(this,mensaje);
		feed_setPopularidadMensaje(this,popularidadMensaje);
		feed_setIdUsuario(this,idUsuario);
		feed_setNick(this,nick);
		feed_setPopularidadUsuario(this,popularidadUsuario);
	}
	return this;
}

void feed_delete(Feed* this)
{
	free(this);
}

int feed_setIdMensaje(Feed* this,int idMensaje)
{
	this->idMensaje = idMensaje;
	return 0;
}

int feed_setMensaje(Feed* this,char* mensaje)
{
	strcpy(this->mensaje,mensaje);
	return 0;
}

int feed_setPopularidadMensaje(Feed* this,int popularidadMensaje)
{
	this->popularidadMensaje = popularidadMensaje;
	return 0;
}

int feed_setIdUsuario(Feed* this,int idUsuario)
{
	this->idUsuario = idUsuario;
	return 0;
}

int feed_setNick(Feed* this,char* nick)
{
	strcpy(this->nick,nick);
	return 0;
}

int feed_setPopularidadUsuario(Feed* this,int popularidadUsuario)
{
	this->popularidadUsuario = popularidadUsuario;
	return 0;
}

int feed_getIdMensaje(Feed* this)
{
	return this->idMensaje;
}

char* feed_getMensaje(Feed* this)
{
	return this->mensaje;
}

int feed_getPopularidadMensaje(Feed* this)
{
	return this->popularidadMensaje;
}

int feed_getIdUsuario(Feed* this)
{
	return this->idUsuario;
}

char* feed_getNick(Feed* this)
{
	return this->nick;
}

int feed_getPopularidadUsuario(Feed* this)
{
	return this->popularidadUsuario;
}

Feed* feed_findByIdMensaje(ArrayList* pArray,int idMensaje)
{

	int i;
	Feed* aux;
	Feed* retorno=NULL;
	for(i=0;i<al_len(pArray);i++)
	{
		aux = al_get(pArray,i);
		if(idMensaje == feed_getIdMensaje(aux))
		{
			retorno = aux;
			break;
		}
	}
	return retorno;
}

Feed* feed_findByMensaje(ArrayList* pArray,char* mensaje)
{

	int i;
	Feed* aux;
	Feed* retorno=NULL;
	for(i=0;i<al_len(pArray);i++)
	{
		aux = al_get(pArray,i);
		if(strcmp(mensaje,feed_getMensaje(aux))==0)
		{
			retorno = aux;
			break;
		}
	}
	return retorno;
}

Feed* feed_findByPopularidadMensaje(ArrayList* pArray,int popularidadMensaje)
{

	int i;
	Feed* aux;
	Feed* retorno=NULL;
	for(i=0;i<al_len(pArray);i++)
	{
		aux = al_get(pArray,i);
		if(popularidadMensaje == feed_getPopularidadMensaje(aux))
		{
			retorno = aux;
			break;
		}
	}
	return retorno;
}

Feed* feed_findByIdUsuario(ArrayList* pArray,int idUsuario)
{

	int i;
	Feed* aux;
	Feed* retorno=NULL;
	for(i=0;i<al_len(pArray);i++)
	{
		aux = al_get(pArray,i);
		if(idUsuario == feed_getIdUsuario(aux))
		{
			retorno = aux;
			break;
		}
	}
	return retorno;
}

Feed* feed_findByNick(ArrayList* pArray,char* nick)
{

	int i;
	Feed* aux;
	Feed* retorno=NULL;
	for(i=0;i<al_len(pArray);i++)
	{
		aux = al_get(pArray,i);
		if(strcmp(nick,feed_getNick(aux))==0)
		{
			retorno = aux;
			break;
		}
	}
	return retorno;
}

Feed* feed_findByPopularidadUsuario(ArrayList* pArray,int popularidadUsuario)
{

	int i;
	Feed* aux;
	Feed* retorno=NULL;
	for(i=0;i<al_len(pArray);i++)
	{
		aux = al_get(pArray,i);
		if(popularidadUsuario == feed_getPopularidadUsuario(aux))
		{
			retorno = aux;
			break;
		}
	}
	return retorno;
}

int feed_compareByIdMensaje(void* pA ,void* pB)
{

	int retorno = 0;

	if(feed_getIdMensaje(pA) > feed_getIdMensaje(pB))
		retorno = 1;
	else if(feed_getIdMensaje(pA) < feed_getIdMensaje(pB))
		retorno = -1;

	return retorno;
}

int feed_compareByMensaje(void* pA ,void* pB)
{

	int retorno;

	retorno = strcmp(feed_getMensaje(pA),feed_getMensaje(pB));

	return retorno;
}

int feed_compareByPopularidadMensaje(void* pA ,void* pB)
{

	int retorno = 0;

	if(feed_getPopularidadMensaje(pA) > feed_getPopularidadMensaje(pB))
		retorno = 1;
	else if(feed_getPopularidadMensaje(pA) < feed_getPopularidadMensaje(pB))
		retorno = -1;

	return retorno;
}

int feed_compareByIdUsuario(void* pA ,void* pB)
{

	int retorno = 0;

	if(feed_getIdUsuario(pA) > feed_getIdUsuario(pB))
		retorno = 1;
	else if(feed_getIdUsuario(pA) < feed_getIdUsuario(pB))
		retorno = -1;

	return retorno;
}

int feed_compareByNick(void* pA ,void* pB)
{

	int retorno;

	retorno = strcmp(feed_getNick(pA),feed_getNick(pB));

	return retorno;
}

int feed_compareByPopularidadUsuario(void* pA ,void* pB)
{

	int retorno = 0;

	if(feed_getPopularidadUsuario((Feed*)pA) > feed_getPopularidadUsuario((Feed*)pB))
	{
	    retorno = 1;
	}
	else if(feed_getPopularidadUsuario((Feed*)pA) < feed_getPopularidadUsuario((Feed*)pB))
    {
        retorno = -1;
    }

	return retorno;
}

void feed_imprimePorMsjFeed(void* pFeed)
{
    if(pFeed!=NULL)
    {
        printf("ID MENSAJE: %d - MENSAJE: %s - POPULARIDAD MENSAJE: %d - ID USUARIO: %d - NICK: %s - POPULARIDAD USUARIO: %d\n\n", feed_getIdMensaje((Feed*)pFeed), feed_getMensaje((Feed*)pFeed), feed_getPopularidadMensaje((Feed*)pFeed), feed_getIdUsuario((Feed*)pFeed), feed_getNick((Feed*)pFeed),feed_getPopularidadUsuario((Feed*)pFeed));
    }
}
