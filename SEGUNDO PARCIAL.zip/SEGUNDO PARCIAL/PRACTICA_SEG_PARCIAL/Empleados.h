#include "ArrayList.h"

#ifndef EMPLEADO_H_INCLUDED
#define EMPLEADO_H_INCLUDED
typedef struct
{
    int id;
    char nombre[51];
    float salario;
    int estado;
}Empleado;
#endif // Empleado_H_INCLUDED

#define EMPLEADO_ESTADO_ACTIVO 0
#define EMPLEADO_ESTADO_INACTIVO 1
#define SALARIO_MINIMO_EMPLEADO 13600

Empleado* emp_new(char* nombre, float salario, int id, int estado);
int emp_delete(Empleado*);
int emp_setNombre(Empleado*,char* nombre);
char* emp_getNombre(Empleado*);
int emp_setSalario(Empleado* this,float salario);
float emp_getSalario(Empleado* this);
int emp_setId(Empleado* this,int id);
int emp_getId(Empleado* this);
int emp_setEstado(Empleado* this,int estado);
int emp_getEstado(Empleado* this);
void vista_mostrarEmpleados(ArrayList* pListaEmpleados);
void emp_imprimeEmpleado(void* pEmpleado);
int emp_salarioEmpleado(void* pEmpleado);

Empleado* emp_findById(ArrayList*, int);




