void cont_init();
int cont_altaX (char* a,char* b,int c);
int cont_bajaX (int id);
int cont_modificarX (int id, char* a,char* b,int c);
int cont_listarX ();
int cont_ordenarX ();

int cont_altaCliente (char* ,char* ,char* );
int cont_bajaCliente (int );
int cont_modificarCliente (int , char* ,char* ,char* );
int cont_listarCliente ();
int cont_ordenarCliente ();
int cont_existeCliente (int id);

