#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Cliente.h"
#include "Alquiler.h"
#include "Vista.h"
#include "DataManager.h"

static ArrayList* nominaClientes;
static ArrayList* nominaAlquiler;
static int proximoIdAlquiler=0;
static int proximoIdsCliente=0;
static int getNewIdsClientes();
static int getNewIdAlquiler();
static int setNewIdClientes(int id);
static int setNewIdAlquiler(int id);

void cont_init()
{
    nominaClientes = al_newArrayList();
    nominaAlquiler= al_newArrayList();
    setNewIdClientes(dm_readAllsClientes(nominaClientes) + 1);
    setNewIdAlquiler(dm_readAllAlquiler(nominaAlquiler) + 1);
    vista_init(VISTA_IDIOMA_ES);
    vista_mostrarMenu();
}

int cont_altasCliente (char* nombre,char* apellido,char* dni)
{
    sCliente* auxsCliente;
    auxsCliente = cli_new(getNewIdsClientes(),dni,nombre,apellido,CLIENTE_ESTADO_ACTIVO);
    al_add(nominaClientes,auxsCliente);
    dm_saveAllsClientes(nominaClientes);
    return 0;
}

int cont_bajasCliente (int id)
{
    sCliente* auxsCliente;
    auxsCliente=cli_findById(nominaClientes,id);
    if(auxsCliente!=NULL)
    {
        cli_setEstado(auxsCliente,CLIENTE_ESTADO_INACTIVO);
        dm_saveAllsClientes(nominaClientes);
    }

    return 0;
}


int cont_modificarsCliente (char* nombre,char* apellido,char* dni, int id, int estado)
{
    sCliente* auxsCliente;

    auxsCliente=cli_findById(nominaClientes,id);

    if(auxsCliente!=NULL)
    {
        cli_setNombre(auxsCliente,nombre);
        cli_setApellido(auxsCliente,apellido);
        cli_setDni(auxsCliente,dni);
        cli_setEstado(auxsCliente,estado);
        dm_saveAllsClientes(nominaClientes);
    }

    return 0;
}

int cont_listarsClientes ()
{
    vista_mostrarsClientes(nominaClientes);
    return 0;
}


static int getNewIdsClientes()
{
    return proximoIdsCliente++;
}

static int setNewIdClientes(int id)
{
    proximoIdsCliente = id;
    return 0;
}

//PARTE ALQUILER


int cont_altaAlquiler (int idCliente, int idEquipo, int tiempoEstimado, int tiempoReal)
{
    Alquiler* auxAlquiler;
    auxAlquiler = alq_new(getNewIdAlquiler(), idCliente, idEquipo, tiempoEstimado,tiempoReal, ALQUILER_ESTADO_ALQUILADO);
    al_add(nominaAlquiler,auxAlquiler);
    dm_saveAllAlquiler(nominaAlquiler);
    return 0;
}

int cont_bajaAlquiler (int id, int tiempoReal)
{
    Alquiler* auxAlquiler;
    auxAlquiler=alq_findById(nominaAlquiler,id);
    if(auxAlquiler!=NULL)
    {
        alq_setEstado(auxAlquiler,ALQUILER_ESTADO_FINALIZADO);
        alq_setTiempoReal(auxAlquiler,tiempoReal);
        dm_saveAllAlquiler(nominaAlquiler);
    }

    return 0;
}


int cont_listarAlquiler ()
{
    //vista_mostrarAlquiler(nominaAlquiler);
    return 0;
}


static int getNewIdAlquiler()
{
    return proximoIdAlquiler++;
}

static int setNewIdAlquiler(int id)
{
    proximoIdAlquiler = id;
    return 0;
}

