#ifndef VISTA_H_INCLUDED
#define VISTA_H_INCLUDED

#endif // VISTA_H_INCLUDED

#define VISTA_IDIOMA_ES 0
#define VISTA_IDIOMA_EN 1

#define MENU_PPAL_ES "\n1. ALTA DE CLIENTE\n2.MODIFICAR CLIENTE \n3.BAJA CLIENTE\n4. LISTA CLIENTES\n5. ALTA VENTA \n6. BAJA VENTAS\n7.IMPRIME VENTAS\n8.IMPRIME VENTAS POR PRODUCTO\n7. Salir\n"
#define MENU_PPAL_ERROR_ES "\nOPCION INVALIDA\n"


int vista_init (int idioma);
int vista_mostrarMenu();
void mostrarError(char * mensaje);

void vista_mostrarClientes(ArrayList* nominaClientes);
void vista_mostrarVentas(ArrayList* nominaVentas);
void vista_imprimeBien();
