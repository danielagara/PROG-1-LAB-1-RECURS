#ifndef DATAMANAGER_H_INCLUDED
#define DATAMANAGER_H_INCLUDED



#endif // DATAMANAGER_H_INCLUDED

int dm_readAllDestinatarios(ArrayList* nominaDestinatarios, char* nombreArchivo);

int dm_saveAllDestinatarios(ArrayList* nominaDestinatarios, char* nombreArchivo);

int dm_readAllListaNegra(ArrayList* nominaListaNegra, char* nombreArchivo);

int dm_saveAllListaNegra(ArrayList* nominaListaNegra, char* nombreArchivo);


void depuralista(ArrayList* nominaDestinatarios, ArrayList* nominaListaNegra);
int compare(ArrayList* nominaListaNegra, sDestinatarios* pDestinatario);
