void cont_init();
int cont_altasLogEntry ();
int cont_listarsLogEntry ();

int cont_altasServices ();
int cont_listarsServices ();

char* cont_nameServicefromId(int serviceId);
char* cont_emailServicefromId(int serviceId);
int filtroArchivos(sLogEntry* pLog);
int funcionSeparadoraSuper(ArrayList* nominasLogEntry, int(*pFunc)(void*), int(*pFuncWar)(void*), int(*pFuncErr)(void*));
int cont_processWarnings(sLogEntry* pLog);
