#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Empleados.h"
#include "dataManager.h"

int main()
{
    ArrayList* nominaEmpleados;
    nominaEmpleados=al_newArrayList();

    dm_readAllEmpleados(nominaEmpleados);
    //vista_mostrarEmpleados(nominaEmpleados);
    //al_map(nominaEmpleados,emp_imprimeEmpleado);
    al_mapReloaded(nominaEmpleados,emp_imprimeEmpleado,emp_salarioEmpleado);
    return 0;
}
