#define ARCHIVO_CLIENTES "clientes.txt"
#define ARCHIVO_ALQUILERES "alquileres.txt"

int dm_readAllsClientes(ArrayList* nominasCliente);
int dm_readAllAlquiler(ArrayList* nominaAlquiler);
