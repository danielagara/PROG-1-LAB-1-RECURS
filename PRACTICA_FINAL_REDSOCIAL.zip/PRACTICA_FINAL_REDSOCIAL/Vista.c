#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Validaciones.h"
#include "ArrayList.h"
#include "Vista.h"
#include "Controlador.h"

#include "Usuario.h"
#include "Post.h"
#include "Feed.h"

static void opcionAltaX();
static void opcionListadoX();
static void opcionOrdenarX();
static int idiomaVista;

int vista_init (int idioma)
{
    idiomaVista = idioma;
    return 0;
}

int vista_mostrarMenu()
{
    char buffer[10];
    int option=0;

    while(option != 6)
    {
        val_getInt(buffer, MENU_PPAL_ES, MENU_PPAL_ERROR_ES,2,5);
        option = atoi(buffer);

        switch(option)
        {
            case 1:
                opcionListadoX();
                break;
            case 2:
                opcionAltaX();
                break;
            case 3:
                //opcionBajaX();
                break;
            case 4:
                //opcionModificacionX();
                break;
            case 5:
                opcionOrdenarX();
                break;
        }
    }

    return 0;
}

void vista_mostrarX(ArrayList* nominaUsuarios, ArrayList* nominaPosts, ArrayList* nominaFeed)
{
    printf("\nIMPRIMO FEED \n");
    al_map(nominaPosts, feed_imprimePorMsjFeed);

}


void mostrarError(char * mensaje)
{

    printf("\nIMPRIMO ERROR\n");

}

static void opcionAltaX()
{
    cont_savesUsuarios();
    cont_savesPosts();

    cont_makesFeed();
}


static void opcionListadoX()
{
    cont_listarX();
}

static void opcionOrdenarX()
{
    cont_ordenarX();
}
