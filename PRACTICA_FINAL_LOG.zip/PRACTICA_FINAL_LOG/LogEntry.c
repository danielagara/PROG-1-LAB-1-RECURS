#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "LogEntry.h"


sLogEntry* LE_new(char* date, char* time, int serviceId, int gravedad, char* msg)
{
    sLogEntry* nuevosLogEntry = malloc(sizeof(sLogEntry));
    LE_setDate(nuevosLogEntry,date);
    LE_setTime(nuevosLogEntry,time);
    LE_setServiceId(nuevosLogEntry,serviceId);
    LE_setGravedad(nuevosLogEntry,gravedad);
    LE_setMsg(nuevosLogEntry,msg);

    return nuevosLogEntry;
}

int LE_delete(sLogEntry* this)
{
    free(this);
    return 0;
}


int LE_setDate(sLogEntry* this,char* date)
{
    strcpy(this->date,date);
    return 0;
}


char* LE_getDate(sLogEntry* this)
{
    return this->date;
}


int LE_setTime(sLogEntry* this,char* time)
{
    strcpy(this->time,time);
    return 0;
}


char* LE_getTime(sLogEntry* this)
{
    return this->time;
}


int LE_setServiceId(sLogEntry* this,char* serviceId)
{
	this->serviceId = serviceId;
    return 0;
}


int LE_getServiceId(sLogEntry* this)
{
    return this->serviceId;
}


int LE_setGravedad(sLogEntry* this,int gravedad)
{

    this->gravedad = gravedad;
    return 0;
}

int LE_getGravedad(sLogEntry* this)
{
    return this->gravedad;
}

int LE_setMsg(sLogEntry* this,int msg)
{
	strcpy(this->msg,msg);
    return 0;
}

char* LE_getMsg(sLogEntry* this)
{
    return this->msg;
}


/*sLogEntry* LE_findById(ArrayList* pArraysLogEntry, int serviceId)
{
    int i;
    sLogEntry *auxsLogEntry;
    void* retorno=NULL;

    for(i=0;i<al_len(pArraysLogEntry);i++)
    {
        auxsLogEntry = al_get(pArraysLogEntry,i);
        if(serviceId == auxsLogEntry->serviceId)
        {
            retorno = auxsLogEntry;
            break;
        }
    }

    return retorno;
}*/

void LE_printLog(void* pLog)
{
    printf("DATE: %s - TIME: %s - SERVICEID: %d - GRAVEDAD: %d - MSG: %s\n", LE_getDate(pLog),LE_getTime(pLog),LE_getServiceId(pLog), LE_getGravedad(pLog),LE_getMsg(pLog));
}
