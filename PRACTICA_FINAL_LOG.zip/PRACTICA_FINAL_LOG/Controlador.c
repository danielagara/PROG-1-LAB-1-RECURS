#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "LogEntry.h"
#include "Services.h"
#include "Warnings.h"
#include "Vista.h"
#include "DataManager.h"

static ArrayList* nominasLogEntry;
static ArrayList* nominasServices;
static ArrayList* nominaWarnigs;

void cont_init()
{
    nominasLogEntry = al_newArrayList();
    nominasServices=al_newArrayList();
    vista_init(VISTA_IDIOMA_ES);
    vista_mostrarMenu();
}

int cont_altasLogEntry ()
{
    dm_readAllLogs(nominasLogEntry);
    return 0;
}


int cont_listarsLogEntry ()
{
    vista_mostrarsLogEntry(nominasLogEntry);
    return 0;
}


//PARTE SERVICES
int cont_altasServices ()
{
    dm_readAllServices(nominasServices);
    return 0;
}


int cont_listarsServices ()
{
    vista_mostrarsServices(nominasServices);
    return 0;
}


//BOTH

int filtroArchivos(sLogEntry* pLog)
{
    int retorno=-1;
    if(LE_getGravedad(pLog)==3 && LE_getServiceId(pLog)!=45)
    {
        retorno=1;
    }
    if(LE_getGravedad(pLog)>=4 && LE_getGravedad(pLog)<=7)
    {
        retorno=2;
    }
    if(LE_getGravedad(pLog)>7)
    {
        retorno=3;
    }

    return retorno;
}

char* cont_nameServicefromId(int serviceId)
{
    int i;
    char retorno[33];

    for(i=0;i<al_len(nominasServices);i++)
    {
        if(serv_getId(al_get(nominasServices, i))==serviceId)
        {
            strncpy(retorno,serv_getName(al_get(nominasServices,i)),33);
            break;
        }
    }
    return retorno;

}

char* cont_emailServicefromId(int serviceId)
{
    int i;
    char retorno[65];

    for(i=0;i<al_len(nominasServices);i++)
    {
        if(serv_getId(al_get(nominasServices, i))==serviceId)
        {
            strncpy(retorno,serv_getEmail(al_get(nominasServices,i)),65);
            break;
        }
    }
    return retorno;

}

int funcionSeparadoraSuper(ArrayList* nominasLogEntry, int(*pFunc)(void*), int(*pFuncWar)(void*), int(*pFuncErr)(void*))
{
    int i;
    int retorno=-1;
    for(i=0;i<al_len(nominasLogEntry);i++)
    {
        if(pFunc(al_get(nominasLogEntry,i))==1)
        {
            pFuncWar(al_get(nominasLogEntry,i));
            retorno=0;
        }

        if(pFunc(al_get(nominasLogEntry,i))==2)
        {
            LE_printLog(al_get(nominasLogEntry,i));//MOD
            retorno=0;
        }

        if(pFunc(al_get(nominasLogEntry,i))==3)
        {
            pFuncErr(al_get(nominasLogEntry,i));
            retorno=0;
        }
    }
}


int cont_processWarnings(sLogEntry* pLog)
{
    sWarnings* auxsWarnings;
    auxsWarnings=war_new(LE_getDate(pLog), LE_getTime(pLog),cont_nameServicefromId(LE_getServiceId(pLog)), LE_getMsg(pLog),cont_emailServicefromId(LE_getServiceId(pLog)));
    al_add(nominaWarnigs, auxsWarnings);
    //PASA AL ARCHIVO TODO DE NUEVO
}
