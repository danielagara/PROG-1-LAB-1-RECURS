#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "socio.h"

/** \brief Reserva espacio en memoria para un nuevo empleado y carga sus datos, devolviendo el puntero al mismo
 *
 * \param
 * \param
 * \return
 *
 */

ESocio* socio_newConstructor(char *nombre,char *apellido, char* DNI,int idSocio)
{
    ESocio* pSocio = malloc(sizeof(ESocio));
    if(pSocio != NULL)
    {
        socio_setNombre(pSocio,nombre);
        socio_setApellido(pSocio,apellido);
		socio_setDNI(pSocio,DNI);
		socio_setEstadoOcupado(pSocio);
        socio_setidSocio(pSocio,idSocio);
    }
    return pSocio;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int socio_setNombre(ESocio* pSocio, char *nombre) //OK
{
    int retorno = -1;
    if(pSocio != NULL)
    {
        retorno = 0;
        strncpy(pSocio->nombre,nombre,NAME_SIZE);
    }
    return retorno;

}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int socio_setApellido(ESocio* pSocio, char *apellido)
{
    int retorno = -1;
    if(pSocio != NULL)
    {
        retorno = 0;
        strncpy(pSocio->apellido,apellido,LAST_NAME_SIZE);
    }
    return retorno;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int socio_setidSocio(ESocio* pSocio, int idSocio)
{

    int retorno = -1;
    if(pSocio != NULL)
    {
        retorno = 0;
        pSocio->idSocio=idSocio;
    }
    return retorno;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int socio_setDNI(ESocio* pSocio, char* DNI)
{
    int retorno = -1;
    if(pSocio != NULL)
    {
        retorno = 0;
        strncpy(pSocio->DNI,DNI,DNI_SIZE);
    }
    return retorno;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int socio_setEstadoOcupado(ESocio* pSocio)
{
    int retorno=-1;
    if(pSocio!=NULL)
    {
        retorno=0;
        pSocio->flagDeEstado=ESTADO_SOCIO_OCUPADO;
    }
    return retorno;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int socio_setEstadoLibre(ESocio* pSocio)
{
    int retorno=-1;
    if(pSocio!=NULL)
    {
        retorno=0;
        pSocio->flagDeEstado=ESTADO_SOCIO_LIBRE;
    }
    return retorno;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int socio_getidSocio(ESocio* pSocio)
{
    int retorno = -1;
    if(pSocio != NULL)
    {
        retorno = pSocio->idSocio;
    }
    return retorno;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

char* socio_getApellido(ESocio* pSocio)
{
    char* retorno = NULL;
    if(pSocio != NULL)
    {
        retorno = pSocio->apellido;
    }
    return retorno;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

char* socio_getNombre(ESocio* pSocio)
{
    char* retorno = NULL;
    if(pSocio != NULL)
    {
        retorno = pSocio->nombre;
    }
    return retorno;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

char* socio_getDNI(ESocio* pSocio)
{
    char* retorno = NULL;
    if(pSocio != NULL)
    {
        retorno = pSocio->DNI;
    }
    return retorno;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int socio_getEstado(ESocio* pSocio)
{
    int retorno = -1;
    if(pSocio != NULL)
    {
        retorno = pSocio->flagDeEstado;
    }
    return retorno;
}
