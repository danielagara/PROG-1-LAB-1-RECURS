#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Empleados.h"


Empleado* emp_new(char* nombre, float salario, int id, int estado)
{
    Empleado* nuevoEmpleado = malloc(sizeof(Empleado));
    emp_setNombre(nuevoEmpleado,nombre);
    emp_setSalario(nuevoEmpleado,salario);
    emp_setId(nuevoEmpleado,id);
    emp_setEstado(nuevoEmpleado,estado);

    return nuevoEmpleado;
}


int emp_delete(Empleado* this)
{
    free(this);
    return 0;
}


int emp_setNombre(Empleado* this,char* nombre)
{
    strcpy(this->nombre,nombre);
    return 0;
}


char* emp_getNombre(Empleado* this)
{
    return this->nombre;
}


int emp_setSalario(Empleado* this,float salario)
{
    this->salario = salario;
    return 0;
}


float emp_getSalario(Empleado* this)
{
    return this->salario;
}



int emp_setId(Empleado* this,int id)
{

    this->id = id;
    return 0;
}

int emp_getId(Empleado* this)
{
    return this->id;
}

int emp_setEstado(Empleado* this,int estado)
{

    this->estado = estado;
    return 0;
}

int emp_getEstado(Empleado* this)
{
    return this->estado;
}


Empleado* emp_findById(ArrayList* pArrayEmpleado, int id)
{
    int i;
    Empleado *auxSocio;
    void* retorno=NULL;

    for(i=0;i<al_len(pArrayEmpleado);i++)
    {
        auxSocio = al_get(pArrayEmpleado,i);
        if(id == auxSocio->id)
        {
            retorno = auxSocio;
            break;
        }
    }

    return retorno;
}



void vista_mostrarEmpleados(ArrayList* pListaEmpleados)
{
    int i;
    Empleado* auxEmpleado;
    for(i=0;i<al_len(pListaEmpleados);i++)
        {
            auxEmpleado=al_get(pListaEmpleados,i);
            if(auxEmpleado->estado==EMPLEADO_ESTADO_ACTIVO)
            {
            auxEmpleado = al_get(pListaEmpleados,i);
            printf("NOMBRE: %s - SALARIO: %f- ID: %d \n",emp_getNombre(auxEmpleado), emp_getSalario(auxEmpleado),emp_getId(auxEmpleado));
            }
        }

}


//int emp_incrementoSalario(Empleado* )

void emp_imprimeEmpleado(void* pEmpleado)
{
    printf("NOMBRE %s - ID %d - SALARIO %f\n", emp_getNombre(pEmpleado), emp_getId(pEmpleado), emp_getSalario(pEmpleado));
}

int emp_salarioEmpleado(void* pEmpleado)
{
    int salarioEmpleado;
    int retorno=-1;
    Empleado* auxEmpleado=(Empleado*)pEmpleado;
    salarioEmpleado=emp_getSalario(auxEmpleado);
    if(salarioEmpleado>=SALARIO_MINIMO_EMPLEADO)
    {
        retorno=0;
    }
    return retorno;
}
