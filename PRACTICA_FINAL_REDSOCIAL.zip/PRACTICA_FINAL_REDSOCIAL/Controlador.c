#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "DataManager.h"
#include "Vista.h"

#include "Usuario.h"
#include "Post.h"
#include "Feed.h"

static ArrayList* nominaPosts;

static ArrayList* nominaUsuarios;

static ArrayList* nominaFeed;

void cont_init()
{
    nominaUsuarios = al_newArrayList();
    nominaPosts = al_newArrayList();
    nominaFeed = al_newArrayList();
    vista_init(VISTA_IDIOMA_ES);
    vista_mostrarMenu();
}

//USUARIOS:
int cont_savesUsuarios()
{
    dm_readAllUsuarios(nominaUsuarios);
    return 0;
}


int cont_listarX ()
{
    vista_mostrarX(nominaUsuarios, nominaPosts, nominaFeed);
    return 0;
}

int cont_ordenarX ()
{
    al_sort(nominaFeed,feed_compareByPopularidadUsuario,0);
    return 0;
}



//POST:

int cont_savesPosts()
{
    dm_readAllPosts(nominaPosts);
    return 0;
}


int cont_makesFeed()
{
    int i;
    int retorno=-1;
    Feed* auxFeed;
    Usuario* auxUsuario;
    for(i=0;i<al_len(nominaPosts);i++)
    {
        auxUsuario=usuario_findByIdUsuario(nominaUsuarios,post_getIdUsuario((Post*)al_get(nominaPosts,i)));
        printf("EL ID DEL USUARIO EN MAKE FEED: %s", usuario_getNick(auxUsuario));
        auxFeed=feed_new(post_getIdMensaje((Post*)al_get(nominaPosts,i)),usuario_getNick(auxUsuario),post_getPopularidad((Post*)al_get(nominaPosts,i)),usuario_getIdUsuario(auxUsuario),post_getMensaje((Post*)al_get(nominaPosts,i)),usuario_getPopularidad(auxUsuario));
        if(al_add(nominaFeed,auxFeed)==0)
        {
            retorno=0;
        }
    }

    return retorno;
}
