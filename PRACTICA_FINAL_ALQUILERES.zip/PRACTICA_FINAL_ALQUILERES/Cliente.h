#ifndef CLIENTE_H_INCLUDED
#define CLIENTE_H_INCLUDED

typedef struct
{
    int id;
    char DNI[50];
    char nombre[50];
    char apellido[50];
    int estado;
}sCliente;

sCliente* cli_new( int id, char* DNI, char* nombre, char* apellido, int estado);
int cli_delete(sCliente* this);
int cli_setDNI(sCliente* this,char* DNI);
char* cli_getDNI(sCliente* this);
int cli_setnombre(sCliente* this,char* nombre);
char* cli_getnombre(sCliente* this);
int cli_setid(sCliente* this,char* id);
int cli_getid(sCliente* this);
int cli_setestado(sCliente* this,int estado);
int cli_getestado(sCliente* this);
int cli_setapellido(sCliente* this,int apellido);
char* cli_getapellido(sCliente* this);
//sCliente* cli_findById(ArrayList* pArraysCliente, int id);
void cli_printCliente(void* pCliente);
#endif // CLIENTE_H_INCLUDED

#define CLIENTE_ESTADO_ACTIVO 1
#define CLIENTE_ESTADO_INACTIVO 0



