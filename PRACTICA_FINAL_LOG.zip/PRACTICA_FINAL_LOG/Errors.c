#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Errors.h"


sErrors* err_new(char* date, char* time, char* name, char* msg, char* email)
{
    sErrors* nuevosErrors = malloc(sizeof(sErrors));
    err_setDate(nuevosErrors,date);
	err_setTime(nuevosErrors,time);
    err_setName(nuevosErrors,name);
	err_setMsg(nuevosErrors,msg);
    err_setEmail(nuevosErrors,email);
    return nuevosErrors;
}

int err_delete(sErrors* this)
{
    free(this);
    return 0;
}


int err_setDate(sErrors* this,char* date)
{
    strcpy(this->date,date);
    return 0;
}


char* err_getDate(sErrors* this)
{
    return this->date;
}


int err_setTime(sErrors* this,char* time)
{
    strcpy(this->time,time);
    return 0;
}


char* err_getTime(sErrors* this)
{
    return this->time;
}


int err_setName(sErrors* this,char* name)
{
	strcpy(this->name,name);
    return 0;
}


char* err_getName(sErrors* this)
{
    return this->name;
}


int err_setEmail(sErrors* this,char* email)
{
	strcpy(this->email,email);
    return 0;
}


char* err_getEmail(sErrors* this)
{
    return this->email;
}


int err_setMsg(sErrors* this,char* msg)
{
	strcpy(this->msg,msg);
    return 0;
}

char* err_getMsg(sErrors* this)
{
    return this->msg;
}


void err_printLog(void* pWarning)
{
    printf("DATE: %s - TIME: %s - NAME: %s - EMAIL: %s - MSG: %s\n", err_getDate(pWarning),err_getTime(pWarning),err_getName(pWarning), err_getEmail(pWarning),err_getMsg(pWarning));
}
