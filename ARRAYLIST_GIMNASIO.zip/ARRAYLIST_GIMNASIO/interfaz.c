#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "interfaz.h"
#include "validar.h"

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

void inter_menuConsola(void)
{
    char bufferInt[3000];
    do
   {
       val_getUnsignedInt(bufferInt,"\n1-ALTA DE SOCIO\n2-BAJA DE SOCIO\n3-MODIFICAR SOCIO\n4-LISTAR SOCIOS\n5-SALIR\n","\nSolo de 1 a 7\n",2,40);
       switch(atoi(bufferInt))
       {
           case 1://ALTA
		   //log_altaSocio();
		   break;

		   case 2://BAJA
		   //log_bajarSocio();
		   break;

		   case 3://MODIFICAR
		   //log_editarSocio();
		   break;

		   case 4://LISTAR
		   //log_listaSocio();
		   break;
        }
    }while( atoi(bufferInt) != 5);
}
