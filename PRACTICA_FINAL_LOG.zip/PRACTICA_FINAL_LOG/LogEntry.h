#ifndef LOGENTRY_H_INCLUDED
#define LOGENTRY_H_INCLUDED

typedef struct
{
    char date[11];
    char time[6];
    int serviceId;
    int gravedad;
    char msg[65];
}sLogEntry;

#endif // LOGENTRY_H_INCLUDED
sLogEntry* LE_new(char* date, char* time, int serviceId, int gravedad, char* msg);
int LE_delete(sLogEntry* this);
int LE_setDate(sLogEntry* this,char* date);
char* LE_getDate(sLogEntry* this);
int LE_setTime(sLogEntry* this,char* time);
char* LE_getTime(sLogEntry* this);
int LE_setServiceId(sLogEntry* this,char* serviceId);
int LE_getServiceId(sLogEntry* this);
int LE_setGravedad(sLogEntry* this,int gravedad);
int LE_getGravedad(sLogEntry* this);
int LE_setMsg(sLogEntry* this,int msg);
char* LE_getMsg(sLogEntry* this);
void LE_printLog(void* pLog);
//sLogEntry* LE_findById(ArrayList* pArraysLogEntry, int serviceId);
