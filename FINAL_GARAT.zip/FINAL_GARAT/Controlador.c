#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "DataManager.h"
#include "Vista.h"

#include "Cliente.h"
#include "Venta.h"
#include "Informes.h"

static ArrayList* nominaClientes;
static int proximoIdCliente=0;
static int getNewIdCliente();
static int setNewIdCliente(int idCliente);

static ArrayList* nominaVentas;
static int proximoIdVenta=0;
static int getNewIdVenta();
static int setNewIdVenta(int idVenta);

void cont_init()
{
    nominaClientes = al_newArrayList();
    setNewIdCliente(dm_readAllClientes(nominaClientes) + 1);

    nominaVentas = al_newArrayList();
    setNewIdVenta(dm_readAllVentas(nominaVentas) + 1);

    vista_init(VISTA_IDIOMA_ES);
    vista_mostrarMenu();
}

int cont_altaClientes(char* nombre,char* apellido,char* DNI)
{
    Cliente* auxCliente;
    auxCliente=cliente_new(getNewIdCliente(),nombre, apellido, DNI, ESTADO_CLIENTE_ACTIVO);
    if(auxCliente!=NULL)
    {
        al_add(nominaClientes,auxCliente);
    }
    dm_saveAllClientes(nominaClientes);
    return 0;
}

int cont_bajaClientes(int id)
{
    Cliente* auxCliente;
    if(cont_validaIdCLienteEnVentas(id)==-1)
    {
        auxCliente=cliente_findByIdCliente(nominaClientes,id);
        cliente_setEstado(auxCliente,ESTADO_CLIENTE_INACTIVO);
    }
    dm_saveAllClientes(nominaClientes);
    return 0;
}


int cont_modificarClientes(int id, char* nombre,char* apellido,char* DNI)
{
    Cliente* auxCliente=cliente_findByIdCliente(nominaClientes,id);

    if(auxCliente!=NULL)
    {
        cliente_setNombre(auxCliente,nombre);
        cliente_setApellido(auxCliente,apellido);
        cliente_setDNI(auxCliente,DNI);
    }

    dm_saveAllClientes(nominaClientes);
    return 0;
}

int cont_listarClientes()
{
    vista_mostrarClientes(nominaClientes);
    return 0;
}

int cont_ordenarClientes()
{
    al_sort(nominaClientes,cliente_compareByApellido,1);
    dm_saveAllClientes(nominaClientes);
    return 0;
}

static int getNewIdCliente()
{
    return proximoIdCliente++;
}

static int setNewIdCliente(int idCliente)
{
    proximoIdCliente = idCliente;
    return 0;
}

int cont_validaIdCLienteExistente(int id)
{
    int retorno=-1;

    if(cliente_findByIdCliente(nominaClientes,id)!=NULL)
    {
        retorno=0;
    }
    return retorno;
}

//VENTAS:

int cont_altaVenta(int id, int codigoProducto, int cantidad)
{
    Venta* auxVenta;
    if(codigoProducto==COD_TV_LG_32)
    {
        auxVenta=venta_new(getNewIdVenta(),id,COD_TV_LG_32,cantidad,PRECIO_1000,ESTADO_VENTA_ACTIVA);
        al_add(nominaVentas,auxVenta);
    }
    if(codigoProducto==COD_PS4)
    {
        auxVenta=venta_new(getNewIdVenta(),id,COD_PS4,cantidad,PRECIO_1001,ESTADO_VENTA_ACTIVA);
        al_add(nominaVentas,auxVenta);
    }
    if(codigoProducto==COD_IPHONE_7)
    {
        auxVenta=venta_new(getNewIdVenta(),id,COD_IPHONE_7,cantidad,PRECIO_1002,ESTADO_VENTA_ACTIVA);
        al_add(nominaVentas,auxVenta);
    }

    dm_saveAllVentas(nominaVentas);
    return 0;
}

int cont_bajaVenta(int id)
{
    Venta* auxVenta;
    auxVenta=venta_findByIdVenta(nominaVentas,id);
    if(auxVenta!=NULL)
    {
        if(venta_setEstado(auxVenta,ESTADO_VENTA_INACTIVA)==0)
        {
            vista_imprimeBien();
        }
    }
    dm_saveAllVentas(nominaVentas);

    return 0;
}


int cont_modificarX (int id, char* a,char* b,int c)
{

    return 0;
}

int cont_listarVentas()
{
    inf_imprimeVentas(nominaClientes,nominaVentas);
    return 0;
}


static int getNewIdVenta()
{
    return proximoIdVenta++;
}

static int setNewIdVenta(int idVenta)
{
    proximoIdVenta = idVenta;
    return 0;
}


int cont_validaIdCLienteEnVentas(int id)
{
    int retorno=-1;

    if(venta_findByIdCliente(nominaVentas,id)!=NULL)
    {
        retorno=0;
    }
    return retorno;
}


int cont_validaIdVentaExistente(int id)
{
    int retorno=-1;

    if(venta_findByIdVenta(nominaClientes,id)!=NULL)
    {
        retorno=0;
    }
    return retorno;
}

void cont_imprimeVentasXProducto(int codigoProducto)
{
    inf_imprimeVentasXProducto(codigoProducto, nominaVentas);
}
