#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "LogEntry.h"
#include "Services.h"
#include "Controlador.h"
#include "DataManager.h"
#include "Vista.h"

int main()
{
    cont_init();
    vista_mostrarMenu();
    return 0;
}
