#ifndef SERVICES_H_INCLUDED
#define SERVICES_H_INCLUDED

typedef struct
{
int id;
char name[33];
char email[65];
}sServices;

#endif // SERVICES_H_INCLUDED
sServices* serv_new(int id, char* name, char* email);
int serv_delete(sServices* this);
int serv_setName(sServices* this,char* name);
char* serv_getName(sServices* this);
int serv_setEmail(sServices* this,char* email);
char* serv_getEmail(sServices* this);
int serv_setId(sServices* this,int id);
int serv_getId(sServices* this);
void serv_printService(void* pService);
