#include "ArrayList.h"

#ifndef _FEED_H
#define _FEED_H
typedef struct
{
	int idMensaje;
	int popularidadMensaje;
	int idUsuario;
	char nick[51];
	char mensaje[120];
	int popularidadUsuario;
}Feed;
#endif// _FEED_H

Feed* feed_new(int idMensaje,char* nick,int popularidadMensaje,int idUsuario,char* mensaje,int popularidadUsuario);
void feed_delete(Feed* this);
int feed_setIdMensaje(Feed* this,int idMensaje);
int feed_setMensaje(Feed* this,char* mensaje);
int feed_setPopularidadMensaje(Feed* this,int popularidadMensaje);
int feed_setIdUsuario(Feed* this,int idUsuario);
int feed_setNick(Feed* this,char* nick);
int feed_setPopularidadUsuario(Feed* this,int popularidadUsuario);
int feed_getIdMensaje(Feed* this);
char* feed_getMensaje(Feed* this);
int feed_getPopularidadMensaje(Feed* this);
int feed_getIdUsuario(Feed* this);
char* feed_getNick(Feed* this);
int feed_getPopularidadUsuario(Feed* this);
Feed* feed_findByIdMensaje(ArrayList* pArray,int idMensaje);
Feed* feed_findByMensaje(ArrayList* pArray,char* mensaje);
Feed* feed_findByPopularidadMensaje(ArrayList* pArray,int popularidadMensaje);
Feed* feed_findByIdUsuario(ArrayList* pArray,int idUsuario);
Feed* feed_findByNick(ArrayList* pArray,char* nick);
Feed* feed_findByPopularidadUsuario(ArrayList* pArray,int popularidadUsuario);
int feed_compareByIdMensaje(void* pA ,void* pB);
int feed_compareByMensaje(void* pA ,void* pB);
int feed_compareByPopularidadMensaje(void* pA ,void* pB);
int feed_compareByIdUsuario(void* pA ,void* pB);
int feed_compareByNick(void* pA ,void* pB);
int feed_compareByPopularidadUsuario(void* pA ,void* pB);
void feed_imprimePorMsjFeed(void* pFeed);
