#ifndef PRODUCTO_H_INCLUDED
#define PRODUCTO_H_INCLUDED

typedef struct
{
    int codigoProducto;
    char descripcion[51];
    float importe;
    int cantidad;
    int estado;
}sProducto;

#endif // PRODUCTO_H_INCLUDED

