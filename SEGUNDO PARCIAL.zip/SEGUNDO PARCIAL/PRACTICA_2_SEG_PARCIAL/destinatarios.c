#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Validaciones.h"
#include "destinatarios.h"
#include <string.h>

sDestinatarios* dest_new(char* nombre, char* apellido, int id, int estado)
{
    sDestinatarios* nuevoDestinatario = malloc(sizeof(sDestinatarios));
    dest_setNombre(nuevoDestinatario,nombre);
    dest_setApellido(nuevoDestinatario,apellido);
    dest_setId(nuevoDestinatario,id);
    dest_setEstado(nuevoDestinatario,estado);

    return nuevoDestinatario;
}


int dest_delete(sDestinatarios* this)
{
    free(this);
    return 0;
}


int dest_setNombre(sDestinatarios* this,char* nombre)
{
    strcpy(this->nombre,nombre);
    return 0;
}


char* dest_getNombre(sDestinatarios* this)
{
    return this->nombre;
}


int dest_setApellido(sDestinatarios* this,char* apellido)
{
    strcpy(this->apellido,apellido);
    return 0;
}


char* dest_getApellido(sDestinatarios* this)
{
    return this->apellido;
}



int dest_setId(sDestinatarios* this,int id)
{

    this->id = id;
    return 0;
}

int dest_getId(sDestinatarios* this)
{
    return this->id;
}

int dest_setEstado(sDestinatarios* this,int estado)
{

    this->estado = estado;
    return 0;
}

int dest_getEstado(sDestinatarios* this)
{
    return this->estado;
}


sDestinatarios* dest_findById(ArrayList* pArrayDestinatario, int id)
{
    int i;
    sDestinatarios* auxDestinatario;
    void* retorno=NULL;

    for(i=0;i<al_len(pArrayDestinatario);i++)
    {
        auxDestinatario = al_get(pArrayDestinatario,i);
        if(id == auxDestinatario->id)
        {
            retorno = auxDestinatario;
            break;
        }
    }

    return retorno;
}



void vista_mostrarDestinatarios(ArrayList* pListaDestinatarios)
{
    int i;
    sDestinatarios* auxDestinatario;
    for(i=0;i<al_len(pListaDestinatarios);i++)
        {
            auxDestinatario=al_get(pListaDestinatarios,i);
            if(auxDestinatario->estado==1)
            {
            auxDestinatario = al_get(pListaDestinatarios,i);
            printf("NOMBRE: %s - APELLIDO: %s- ID: %d \n",dest_getNombre(auxDestinatario), dest_getApellido(auxDestinatario),dest_getId(auxDestinatario));
            }
        }

}


void dest_imprimeDestinatario(void* pDestinatario)
{
    printf("NOMBRE %s - ID %d - APELLIDO %s\n", dest_getNombre(pDestinatario), dest_getId(pDestinatario), dest_getApellido(pDestinatario));
}
