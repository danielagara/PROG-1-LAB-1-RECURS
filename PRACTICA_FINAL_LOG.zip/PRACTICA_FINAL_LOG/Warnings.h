#ifndef WARNINGS_H_INCLUDED
#define WARNINGS_H_INCLUDED

typedef struct
{
    char date[11];
    char time[6];
    char name[33];
    char msg[65];
    char email[65];
}sWarnings;

#endif // WARNINGS_H_INCLUDED
sWarnings* war_new(char* date, char* time, char* name, char* msg, char* email);
int war_delete(sWarnings* this);
int war_setDate(sWarnings* this,char* date);
char* war_getDate(sWarnings* this);
int war_setTime(sWarnings* this,char* time);
char* war_getTime(sWarnings* this);
int war_setName(sWarnings* this,char* name);
char* war_getName(sWarnings* this);
int war_setEmail(sWarnings* this,char* email);
char* war_getEmail(sWarnings* this);
int war_setMsg(sWarnings* this,char* msg);
char* war_getMsg(sWarnings* this);
void war_printLog(void* pWarning);
