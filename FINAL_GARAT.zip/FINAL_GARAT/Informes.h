#ifndef INFORMES_H_INCLUDED
#define INFORMES_H_INCLUDED



#endif // INFORMES_H_INCLUDED
void inf_imprimeVentasXProducto(int codProducto, ArrayList* nominaVentas);
void inf_imprimeVentas(ArrayList* nominaClientes, ArrayList* nominaVentas);
